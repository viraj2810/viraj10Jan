package Keywords_and_identifiers;

public class Sample1 
{
      int a=10;
	
	public static void main(String[] args) 
	{
		m1$_();
		
	}
	
	public static void m1$_() 
	{
		System.out.println("Hi");
	}
	
	
}
