package Types_of_Variables;

public class local1 
{
   //local variable
	public static void main(String[] args) 
	{
		m1(20);         //methodname
		
	}
	
	public static void m1(int b)   //local variable
	{
		int a=10;                      //local variable
		System.out.println(a);
		System.out.println(b);
	}
	
	
	public void m2() 
	{
		
	}
	
	
	
	
}
