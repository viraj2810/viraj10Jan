package Types_of_Variables;

public class staticsame_1 
{
	  // static global variable call from same class
	     static int c=50;                  // static global variable
	
	public static void main(String[] args) 
	{
		
		System.out.println(c);        //variablename
		
		
	}
	
	
	
	
	
}
