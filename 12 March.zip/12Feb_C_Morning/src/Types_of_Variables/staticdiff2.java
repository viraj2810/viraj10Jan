package Types_of_Variables;

public class staticdiff2 
{
	 //static global variable
	
	  static int d=70;
	
	
	
	
}
