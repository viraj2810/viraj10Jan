package Types_of_Variables;

public class non_staticdiff1 
{
	 // non static/instance global variable call from different class
	
	public static void main(String[] args)
	{
		
		//create object of different class
		non_staticdiff2 S2=new non_staticdiff2();
		
		// call variable
		System.out.println(S2.X);    // objectname.variablename
		
	}
	
	

}
