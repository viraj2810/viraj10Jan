package Types_of_Variables;

public class non_staticdiff2 
{

	 // non static/instance global variable 
	
	      int X=100;
	
	
	
}
