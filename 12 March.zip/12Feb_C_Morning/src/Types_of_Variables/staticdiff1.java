package Types_of_Variables;

public class staticdiff1 
{
      //Static global variable call from different class
	
	public static void main(String[] args)
	{
		System.out.println(staticdiff2.d);           //clasname.variablename
		
		
	}
	
	
	
	
	
	
	
	
}
