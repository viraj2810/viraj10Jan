package Types_of_Variables;

public class non_static1
{    // non static/instance global variable call from same class
          
	   int z=60;                         // non static/instance global variable
	
	public static void main(String[] args) 
	{
		
		// create object of same class
		non_static1 S1=new non_static1();
		
		// call variable
		System.out.println(S1.z);           //objectname.variablename
		
	}
	
	
	public void m1() 
	{
		System.out.println(z);
	}
	
	
	
	
}
