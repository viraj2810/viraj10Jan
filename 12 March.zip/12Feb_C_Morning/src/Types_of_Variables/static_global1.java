package Types_of_Variables;

public class static_global1 
{  // static global variable call from same class
	
	static int a=30;    // static global variable
	 
	public static void main(String[] args)
	{
		System.out.println(a);         //variablename
		
	}
	
	public static void m1()   
	{
		System.out.println(a);          //variablename
	}
	
	
	public void m2() 
	{
		System.out.println(a);         //variablename
	}
	
	
	
	

}
