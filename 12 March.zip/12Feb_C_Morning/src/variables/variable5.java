package variables;

public class variable5 
{
   // class body
	

	 public static void main(String[] args)  
	 { 
		 	//variable declaration   
	   
	      String Sname;
		 
		 
	                         
	   
		 //Variable initialization 
	 
	      Sname="Boxed objects always require 8 bytes for type and memory management, and because the size of objects is always a multiple o";
	   
	 
	   
		 //Usage 

	   System.out.println(Sname);
	      
	   
	 
	   
	 } 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
