package variables;

public class Variable2 
{
	
	public static void main(String[] args)
	{
		
		//1. Variable declaration (Allocating/Reserving memory)
		
		   String  studentname;                    //dataType  variableName;
		
		
		// 2.	Variable Initialization (Assigning or inserting value)
		
		 studentname="Nilesh";                      // variableName="variable information";
		   
		   
		  //3.	Usage
		 
		 System.out.println(studentname);           // Variable
		 	 
		   
	}
	
	
	
}
