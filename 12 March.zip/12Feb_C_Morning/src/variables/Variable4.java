package variables;

public class Variable4 
{

	 public static void main(String[] args)  
	 { 
	  //variable declaration 
	  String Studentname;              //DataType  VariableName 
	   
	  int StudentRollno;               //DataType  VariableName 
	                         
	  char Studentgrade;               //DataType  VariableName 
	   
	 double Studentpercentage;         //DataType  VariableName 
	   
	  //Variable initialization 
	  Studentname="Rohit";            // VariableName= "Variable Information"; 
	   
	  StudentRollno=10;                // VariableName= Variable Information; 
	   
	  Studentgrade='A';               // VariableName= 'Variable Information'; 
	   
	  Studentpercentage=60.20f;       // VariableName= Variable Information f; 
	   
	   
	  //Usage 
	  System.out.println("Student Name: "+Studentname);         // VariableName 
	   
	  System.out.println("Student Roll No: "+StudentRollno);      // VariableName 
	   
	  System.out.println("Student Grade: "+Studentgrade);       // VariableName 
	   
	  System.out.println("Student Percentage: "+Studentpercentage+ "%");  // VariableName 
	   
	   
	 } 
	

	
}
