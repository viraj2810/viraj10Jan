package variables;

public class Variable1 
{
   // Class body
	
	public static void main(String[] args) 
	{
		// Main method body
		
		
		System.out.println("Ramesh");
		
		
		
		
	}
	

	
}
