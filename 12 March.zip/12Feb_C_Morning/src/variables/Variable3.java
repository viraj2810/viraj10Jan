package variables;

public class Variable3 
{
	
	 public static void main(String[] args)  
	 { 
	  //variable declaration 
	  String Studentname;              //DataType  VariableName 
	   
	  int StudentRollno;               //DataType  VariableName 
	                         
	  char Studentgrade;               //DataType  VariableName 
	   
	  float Studentpercentage;         //DataType  VariableName 
	   
	  //Variable initialization 
	  Studentname="Rohit";             // VariableName= "Variable Information"; 
	   
	  StudentRollno=10;                // VariableName= Variable Information; 
	   
	  Studentgrade='A';               // VariableName= 'Variable Information'; 
	   
	  Studentpercentage=60.25f;       // VariableName= Variable Information f; 
	   
	   
	  //Usage 
	  System.out.println(Studentname);         // VariableName 
	   
	  System.out.println(StudentRollno);      // VariableName 
	   
	  System.out.println(Studentgrade);       // VariableName 
	   
	  System.out.println(Studentpercentage);  // VariableName 
	   
	   
	 } 
	  

}
