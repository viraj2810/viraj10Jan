package Genearlisation;

public class VI implements Simcard
{

	public void SMS()  
	 {
		 System.out.println("150 SMS");
	 } 
    
    public void Audiocalling() 
    {
   	 System.out.println("200 Min");
    }

   public void Internet() 
   {
   	System.out.println("3 GB");
   }
	
	
	
	
	
	
	
	
	
}
