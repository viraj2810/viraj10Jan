package Genearlisation;

public class Airtel implements Simcard
{

	 public void SMS()  
	 {
		 System.out.println("50 SMS");
	 } 
     
     public void Audiocalling() 
     {
    	 System.out.println("100 Min");
     }

    public void Internet() 
    {
    	System.out.println("2 GB");
    }
	
	
	
	
	
	
	
}
