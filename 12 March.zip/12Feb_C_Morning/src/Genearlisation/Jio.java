package Genearlisation;

public class Jio implements Simcard
{
	
	 public void SMS() 
	 {
		System.out.println("100 SMS"); 
	 }                
     
   public void Audiocalling() 
   {
	   System.out.println("Unlimited"); 
   }

   public void Internet()
   {
	   System.out.println("1.5GB");   
   }
	
	
	
	

}
