package Genearlisation;

public interface Simcard 
{      //super interface
	
	       void SMS();             //abstract public void SMS();    
	       
	       void Audiocalling();
	
	       void Internet();
	
	
	
	

}
