package polymorphism;

public class Father 
{  //Method overriding
	
  //Super class
	public void money() 
	{
		System.out.println("Money:1 lakh");
	}
	
	public void car() 
	{
		System.out.println("Car:Honda city");
	}
	
	public void Home() 
	{
		System.out.println("Home:2 BHK");
	}
	
	private void bike() 
	{
		System.out.println("Unicorn");
	}
	
	public static void m1() 
	{
		System.out.println("Hi");
	}
	
	
	
}
