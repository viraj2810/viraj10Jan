package polymorphism;

public class test1 
{
	public static void main(String[] args) 
	{
		m1();
	}
	
	public static void m1()               //method declaration
	{
		System.out.println("Hi");         //Method defination
	}
	
	public void m2()                       //method declaration
	{
		System.out.println("Hello");       //Method defination
	}

}
