package polymorphism;

public class test3 
{

	public static void main(String[] args) 
	{
		test2 T2=new test2();
		T2.addition(10, 20);
		
		T2.addition(20, 30, 40);
		
		T2.addition(10, 20, 30, 40);
		
		
		
		
		
	}
	
	
	
	
	
	
	
}
