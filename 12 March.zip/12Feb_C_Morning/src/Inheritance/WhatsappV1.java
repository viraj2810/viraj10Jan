package Inheritance;

public class WhatsappV1 
{
	//super class
	public void Textmsg() 
	{
		System.out.println("Text Message");
	}
	
	

}
