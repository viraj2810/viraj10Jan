package Inheritance;

public class Son1 extends H_father
{

	public void Mobile() 
	{
		System.out.println("Samsung");
	}
	
	
}
