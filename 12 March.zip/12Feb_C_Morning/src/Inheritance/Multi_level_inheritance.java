package Inheritance;

public class Multi_level_inheritance
{
    //Multi level inheritance->3 or more classes 
	public static void main(String[] args) 
	{
		//Create object of different class
		WhatsappV3 S1=new WhatsappV3();
		//Call the methods
		
		S1.Videocalling();
		S1.Audiocalling();
	    S1.Textmsg();
	}
	
}
