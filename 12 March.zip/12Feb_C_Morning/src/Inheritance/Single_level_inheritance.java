package Inheritance;

public class Single_level_inheritance 
{
	//Single level inheritance---->2 classes 
	public static void main(String[] args)
	{
		//create object of different class
	        	Son S1=new Son();
		  //call the methods
		    S1.Mobile();
		    S1.car();
		    S1.Money();
		    S1.Home();
		
	}
	
	
	
	
	
	
	
	

}
