package Inheritance;

public class father 
{  
	//Super class
	
	public void car() 
	{
		System.out.println("Car:Swift");
	}
	
	public void Money() 
	{
		System.out.println("Money:5 Lakh");
	}
	
	public void Home() 
	{
		System.out.println("Home:2 BHK");
	}
	
	
	
	
	
	
	
	

}
