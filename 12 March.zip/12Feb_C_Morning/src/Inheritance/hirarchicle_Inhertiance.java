package Inheritance;

public class hirarchicle_Inhertiance 
{
	 public static void main(String[] args) 
	 { 
		 //Create object of Son1 class
		 Son1 S1=new Son1();
		 S1.Mobile();
		 S1.Property();
		 
		 //Create object of Son2 class
		 Son2 S2=new Son2(); 
		 S2.Bike();
		 S2.Property();
		 
		 //Create object of Son3 class
		 Son3 S3=new Son3(); 
		 S3.laptop();
		 S3.Property();
		 
		 
	}
	
	
	
	
	
}
