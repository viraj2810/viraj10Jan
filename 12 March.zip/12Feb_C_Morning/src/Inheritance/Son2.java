package Inheritance;

public class Son2 extends H_father
{
	public void Bike() 
	{
		System.out.println("Unicorn");
	}
	
}
