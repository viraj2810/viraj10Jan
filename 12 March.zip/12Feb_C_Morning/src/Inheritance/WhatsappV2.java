package Inheritance;

public class WhatsappV2 extends WhatsappV1 
{
       // subclass
	public void Audiocalling() 
	{
		System.out.println("Audio calling");
	}
	
	
	
	
	
	
}
