package Inheritance;

public class Son extends father
{
	// Sub class
	
	public void Mobile() 
	{
		System.out.println("Samung A50");
	}

	

	
	
	
	
	
	
	
	
	
	
	
	
}
