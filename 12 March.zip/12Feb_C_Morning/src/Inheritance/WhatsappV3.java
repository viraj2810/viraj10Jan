package Inheritance;

public class WhatsappV3 extends WhatsappV2
{

	public void Videocalling() 
	{
		System.out.println("Video calling");
	}
	
	
	
	
	
	
	
	
	
	
}
