package Inheritance;

public class Son3 extends H_father
{
	public void laptop() 
	{
		System.out.println("Dell");
	}
	
	
}
