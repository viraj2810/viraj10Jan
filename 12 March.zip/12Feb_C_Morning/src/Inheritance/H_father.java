package Inheritance;

public class H_father 
{

	public void Property() 
	{
		System.out.println("Home, Car, Money");
	}
	
	
	
	
}
