package Main_Method;

public class Main_method_Changes 
{

	
	public static void main(String[] args) 
	{
		System.out.println("Hi");
	
	}
	
	public static void main(int[] args) 
	{
		
		System.out.println("Hello");
	}
	
	public static void main(char[] x) 
	{
		
	}
	
	
	
	
	
}
