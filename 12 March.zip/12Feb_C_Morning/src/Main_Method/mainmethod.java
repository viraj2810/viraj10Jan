package Main_Method;

public class mainmethod 
{
	
	public static void main(String[] args)
	{
		
	       int Num1=addition(20,50);
		
		System.out.println(Num1);
		
	}
	
	public static int addition(int a, int b) 
	{
		     int Sum=a+b;  //70
		
		    return Sum;//70
		
	}
	
	
}
