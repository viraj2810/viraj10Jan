package Loops;

public class while_loop1 
{
	    // Print 1 to 5 no.
	public static void main(String[] args)
	{
			int i=1;                    // Start condition
			
			     
			while(i<=5)              //end condition
			{
				System.out.println(i); //1  2   3  4  5
				
				i++;               //increment/decrement
			}
		
		
		
		
	}
	
	
	
	

}
