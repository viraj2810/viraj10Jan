package Loops;

public class do_while1 
{
  // print 1 to 5 no
	public static void main(String[] args) 
	{
		
		     int i=1;                         // starting condition
		
		   do 
		   {
			   System.out.println(i);         //1  2  3   4  5
			   
			     i++;                    // increment/decrement
		   }  
		   while(i<=5);                    // end condition
		     
		
		
	}
	
	
	
	
}
