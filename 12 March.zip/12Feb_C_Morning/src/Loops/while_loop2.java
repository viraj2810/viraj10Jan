package Loops;

public class while_loop2 
{

	   // Print 10 to 20 no.
		public static void main(String[] args)
		{
				int i=10;                    // Start condition
				
				     
				while(i<=20)              //end condition
				{
					System.out.println(i); 
					
					i++;            //increment/decrement
				}
			
			
			
			
		}
		
		
	
	
	
	
}
