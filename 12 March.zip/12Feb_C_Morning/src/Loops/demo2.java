package Loops;

import Access_specifier.sample6;

public class demo2 extends sample6
{

	public static void main(String[] args) 
	{
		demo2 d2=new demo2();
		d2.m1();
		
		System.out.println(d2.c);
		
	}
	
	
	
	
	
	
	
	
}
