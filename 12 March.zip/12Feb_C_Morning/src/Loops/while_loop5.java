package Loops;

public class while_loop5 
{
	
	// print "Hi"----->10 times
	
	  
		public static void main(String[] args)
		{
				int i=1;                    // Start condition
				
				    
				while(i<=10)                 //end condition
				{
					System.out.println("Hi"); 
					
					i++;                   //increment/decrement
				}
			
		
			
			
		}
	
	

}
