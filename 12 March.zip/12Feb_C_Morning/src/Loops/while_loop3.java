package Loops;

public class while_loop3
{
	 // Print odd no from 1 to 7 no.
	public static void main(String[] args)
	{
			int i=1;                    // Start condition
			
			     
			while(i<=7)              //end condition
			{
				System.out.println(i); //1  3  5  7
				
				i=i+2;         //increment/decrement
			}
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
}
