package Loops;

public class while_loop4 
{
    // Print odd no from 99 to 1 no.
	public static void main(String[] args)
	{
		    int i=99;                    // Start condition
			
			   
			while(i>=1)              //end condition
			{
				System.out.println(i); 
				
				i=i-2;              //increment/decrement
			}
		
		
		
		
	}
	
	
	
	
	
	
}
