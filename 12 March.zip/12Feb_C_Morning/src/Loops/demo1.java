package Loops;

import Access_specifier.sample1;

public class demo1 extends sample1
{

	public static void main(String[] args)
	{
		    // Create object
		sample1 S1=new sample1();
		//call the method
		     S1.M1();
		     S1.M2();
		
		System.out.println(S1.a);
		
	}
	
	
	
	
	
	
}
