package Loops;

public class For_loop5 
{

	// Print 5 to 1 no.
		public static void main(String[] args) 
		{
			     //i=5     5>=1     4
			             //4>=1     3
			             //3>=1     2
			             //2>=1      1
			              //1>=1     0
			             //0>=1
			for(int i=5;   i>=1;    i--) 
			{   
				System.out.println(i); //5 4  3   2  1
		
			}
			
			
			
		}

	
	
	
	
}
