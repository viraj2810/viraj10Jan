package Constructor;

public class Sample2 
{
	// non-static regular method
		public void addition()
		{
			int a=5;
			int b=10;
			int sum=a+b;
			System.out.println(sum);
		}
	
	
	
	
	
	
	
}
