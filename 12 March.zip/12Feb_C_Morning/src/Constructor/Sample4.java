package Constructor;

public class Sample4 
{

	//Step-I: Variable declartion (Non-static global variable)
		//Use-I:It copies the member of class into an object---->after creation of object
		//Use-II: Initialize non-static globle variable
		
		      int c; //50              //datatype variablename;
		      int d;  //10           //datatype variablename;
		
	      //Variable initialisation      
		  Sample4()                     //user defined constructor
		 {
			 c=50;
			 d=10;
		 }
	
		  //usage
		  public void division() 
		  {
			     int divvalue=c/d;
			     System.out.println(divvalue);
		  }
		  
		public static void main(String[] args) 
		{
			//create object of same class
			Sample4 S4=new Sample4();
			     S4.division(); 
			     
			  //create object of different class
			   Sample3 S3=new Sample3();   
			   S3.addition();
			  S3.multiplication();
		}
		  
		  
		  
}
