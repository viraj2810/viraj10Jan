package Constructor;

public class Sample6 
{
	
	public static void main(String[] args) 
	{
		
		//create object of different class
		   Sample5 S1=new Sample5();
		     S1.addition();
		     S1.multiplication();
		     
		//create object of different class   
		     Sample5 S2=new Sample5(25,20);    
		     S2.addition();
		     S2.multiplication();
		     
		   //create object of different class 
		     Sample5 S3=new Sample5(15,10);    
		     S3.addition();
		     S3.multiplication();
		     
		   //create object of different class          
		     Sample5 S4=new Sample5("Rohit");
		     S4.studentinfo();
		     
	}
	
	
	
	
	
	
	
	

}
