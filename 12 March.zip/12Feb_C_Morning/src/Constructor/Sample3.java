package Constructor;

public class Sample3 
{
      //Step-I: Variable declartion (Non-static global variable)
	//Use-I:It copies the member of class into an object---->after creation of object
	//Use-II: Initialize non-static globle variable
	
	      int a;   //10            //datatype variablename;
	      int b;    //20           //datatype variablename;
	
	  //Step-II: Variable initialization
	      Sample3()                   //user-defined constructor   
	      {
	    	a=10;
	    	b=20;	  
	      }
	
	// Step-III: usage
	      public void addition() 
	      {
	    	  int Sum=a+b;
	    	  System.out.println(Sum);
	      }
	      
	     public void multiplication()
	     {
	    	    int mulvalue=a*b;
	    	    System.out.println(mulvalue);
	     } 
	      
	   
	     public static void main(String[] args) 
	     {
			//create object of same class 
	    	 Sample3 S1=new Sample3();
	    	 //call the methods
	    	   S1.addition();
	    	   S1.multiplication();
	    	 
		 }
	     
	     
	     
	      
}
