package Access_specifier;

public class sample3 
{
	      private int a=50;
	
	public static void main(String[] args) 
	{
		sample3 S3=new sample3();
		S3.m1();
		
		System.out.println(S3.a);
		
	}

	
	private void m1()
	{
		System.out.println("Hi");
	}
	
	
	
	
}
