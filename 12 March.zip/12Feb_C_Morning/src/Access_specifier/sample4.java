package Access_specifier;

public class sample4 
{

	public static void main(String[] args) 
	{
		
		sample5 S6=new sample5();
		   S6.m2();
		
		System.out.println(S6.a);
	}
	
	
	
	
	
	
	
	
}
