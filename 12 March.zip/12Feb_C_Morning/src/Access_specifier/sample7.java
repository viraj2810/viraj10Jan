package Access_specifier;

public class sample7 
{
     public static void main(String[] args) 
     {
    	 sample6 s7=new sample6();
    	    s7.m1();
    	 System.out.println(s7.c);
	}
	
	
	
	
	
	
	
}
