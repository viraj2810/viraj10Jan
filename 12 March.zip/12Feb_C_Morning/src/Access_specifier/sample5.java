package Access_specifier;

public class sample5
{
         int a=70;
	public static void main(String[] args) 
	{
		sample5 S5=new sample5();
		S5.m2();
		System.out.println(S5.a);
		
	}
	
	 void m2() 
	{
		System.out.println("Hello");
	}
	
	
	
	
	
}
