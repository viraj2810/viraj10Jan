package Access_specifier;

public class sample2 
{

	
	public static void main(String[] args) 
	{
		//create object of different class
		   sample1 S1=new sample1();
		      S1.M1();
		     
		     System.out.println(S1.a);
		      
		      
		
	}
	
	
	
	
	
	
	
	
	
}
