package Access_specifier;

public class sample1 
{
     public int a=10;
   public static void main(String[] args)
   {
	
	   
	   
	   
   }
   
   
   
   public void M1() 
   {
	   System.out.println("Good morning");
   }
   
   public void M2() 
   {
	   System.out.println("Good Afternoon");
   }
   
	
}
