package Control_Statements;

public class If3_else 
{
	// if else------> 2 condition check
	public static void main(String[] args) 
	{
		
		    int marks=30;                       //Staring condition
		
		      //30>=35
		     if(marks>=35)                    //end condition
		     {
		    	System.out.println("Pass"); 
		    	
		     } 
		     else 
		     {
		    	System.out.println("Fail"); 
		     }
		
	}
	
	
	
	
	
	
	
	
}
