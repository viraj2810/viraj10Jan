package Control_Statements;

public class If1 
{
    // if------> 1 condition check
	public static void main(String[] args) 
	{
		
		  int marks=50;                          // starting condition
		
		   //50>=35
		if(marks>=35)                                     //end condition
		{
			System.out.println("Pass");
		}
		
	
	}
	
	
	
	
	
	
	
	
}
