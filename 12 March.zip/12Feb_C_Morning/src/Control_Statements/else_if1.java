package Control_Statements;

public class else_if1 
{
    //else if------>multiple condition
	public static void main(String[] args) 
	{      
		   int marks=50;                          // starting condition
		  
		  
		if(marks>=65)                           //end condition
		{
			System.out.println("Distinction");
		}
		        
		else if(marks>=60)                                //end condition
		{
			System.out.println("1st class");
		}
		      
		else if(marks>=55) 
		{
			System.out.println("higher 2nd class");
		}
		       
		else if(marks>=50) 
		{
			System.out.println("2nd class");
		}
		     
		else if(marks>=35) 
		{
			System.out.println("Pass");
		}
		else 
		{
			System.out.println("Fail");
		}
		
		
		
		
	}
	
	
	
	
	
	
	
}
