package String;

public class string1 
{

	
	public static void main(String[] args)
	{
		
		String S1=new String("ABC");
		
		System.out.println(S1);
		//OR
		
		//String declartion & Initilisation
		
		String S2="Virat";
		
		       S2=S2+ " "+"Kohli";
		
		System.out.println(S2);
		
		
	}
	
	
	
	
}
