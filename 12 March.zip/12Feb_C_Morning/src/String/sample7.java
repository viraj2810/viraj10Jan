package String;

public class sample7 
{

	final public void m1() 
	{
		System.out.println("Hi");
	}
}
