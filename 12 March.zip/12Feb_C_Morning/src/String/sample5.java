package String;

final public class sample5 
{

	
	public void m1() 
	{
		System.out.println("Hi");
	}
	
	
	
	
	
}
