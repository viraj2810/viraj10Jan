package String;

final public class String2 
{

	public static void main(String[] args) 
	{
		
	}
	
	public void m1() 
	{
		System.out.println("Hi");
	}
	
	
	
	
}
