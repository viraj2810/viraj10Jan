package String;

public class Sample4 
{

	public static void main(String[] args) 
	{
		//String declartion and initilisation
		   String S1="abc";            // without using new keyword
		     
		   //OR
		   
		String S2=new String("abc");               //Classname objectname=new Classname();   
		System.out.println(S2);
		
	}
	
	
	
	
	
	
	
}
