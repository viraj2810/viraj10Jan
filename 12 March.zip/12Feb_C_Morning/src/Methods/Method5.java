package Methods;

public class Method5 
{          //non-static regular method call from same class 
	public static void main(String[] args) 
	{
		System.out.println("Main method started");
		
		// Create Object of same class
		Method5 S1=new Method5();            //classname objectname=new classname();
		// call the method
		  S1.m5();                           //objectname.methodname();     
		
		  S1.m6();                         //objectname.methodname(); 
		System.out.println("Main method ended");
		 
	}
	//Non-static regular method
		public void m5() 
		{
			System.out.println("Non-Static regular method is running from same class: m5");
			
		} 
	//Non-static regular method
		public void m6() 
		{
			System.out.println("Non-Static regular method is running from same class: m6");
			
		} 
		
	
	
	

}
