package Methods;

public class Method10 
{

	public static void main(String[] args) 
	{
		   addition();                            //methodname();
		
		  addition(20,30);                         //methodname();
		  addition(100,100);
		  
		 addition(50,60,70); 
		 addition(20,20,30);
	}
	
	//Static regular method------>Without parameter/zero parameter method
	public static void addition() 
	{
		//variable  decl & variable initilisation
		int a=10;
		int b=20;	
		int c=a+b;
		System.out.println(c);	
	}
	//Static regular method------>With parameter method----> 2 int parameter
	public static void addition(int a, int b) 
	{
		int c=a+b;
		System.out.println(c);
	}
	//Static regular method------>With parameter method----> 3 int parameter
	public static void addition(int P, int Q,int R) 
	{
		
	      int Sum =P+Q+R;
	      
	      System.out.println(Sum);
	}
	
	
	
	
}
