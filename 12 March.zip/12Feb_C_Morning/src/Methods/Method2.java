package Methods;

public class Method2
{
	// Static regular method call from different class
	
	public static void main(String[] args)
	{
		
		System.out.println("Main method started");
		
		// Call Static regular method
		Method3.m3();                              //classname.methodname();
		
		
		method4.m4();                              //classname.methodname();
		
		System.out.println("Main method ended");
		
		
		
	}
	
	
	
	
	
	
	
	
	
}
