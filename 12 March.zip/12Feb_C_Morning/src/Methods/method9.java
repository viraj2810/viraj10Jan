package Methods;

public class method9
{

	   //static regular method
		public static void m13() 
		{
			System.out.println("Good morning");
		}
		
		//Non-static regular method
		public  void m14() 
		{
			System.out.println("Good Evening");
		}
	
		//Non-static regular method
		public  void m15() 
		{
			System.out.println("Good Night");
		}
	
		
	
	
	
	
}
