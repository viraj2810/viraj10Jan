package Methods;

public class Method3 
{

	   //Static regular method
	
	public static void m3() 
	{
		 System.out.println("Static regular method is running from different class: m3");
		
	}
	
	
	
	
	
	
	
	
	
}
