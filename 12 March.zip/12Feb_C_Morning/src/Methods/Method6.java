package Methods;

public class Method6 
{
	
	public static void main(String[] args) 
	{
		System.out.println("Main method started");
		
		// create object of different class                              
		Method7 S2=new Method7();                   // classname objectname=new classname();
		// Call the method
		     S2.m7();                              //objectname.methodname();
		    
		System.out.println("Main method ended");		 
	}
	

}
