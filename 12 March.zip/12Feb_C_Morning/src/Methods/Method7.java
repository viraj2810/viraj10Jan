package Methods;

public class Method7 
{
	// Non-static regular method
	
	public void m7() 
	{
		
		System.out.println("Non-Static regular method is running from differnt class: m7");
	}

}
