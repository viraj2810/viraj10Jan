package Methods;

public class method8 
{
	
	public static void main(String[] args) 
	{   //static regular method call from same class
		       m10();                                      //methodname();
		
		//Create Object of same/current class
		method8  Z1=new method8();                        // classname objectname=new classname();
		// call the methods
		     Z1.m11();                                   // Objectname.methodname();
		     Z1.m12();                                   // Objectname.methodname();
		     
		     
		 //static regular method call from different class     
		     method9.m13();                               // Classname.methodname();
		     
		 //Non-static regular method from different class 
		     method9 Z2=new method9();                 // classname objectname=new classname();
		     //Call the methods
		     Z2.m14();                                   // Objectname.methodname();
		     Z2.m15();
		     
		    
		     m20(); 
		     
	}
	
	//static regular method
	public static void m10() 
	{
		System.out.println("Hi");
		System.out.println("I am an indian");
	}
	
	//Non-static regular method
	public  void m11() 
	{
		System.out.println("Hello");
	}
	
	//Non-static regular method
		public  void m12() 
		{
			System.out.println("gshlhvsjkbdbdk");
		}
	
	
		//static regular method
		public static void m20() 
		{
			System.out.println("bye");
			
		}
			
		
		

}
