package Methods;

public class Method1 
{	// Class body
	
    //Static regular method call from same class
	public static void main(String[] args) 
	{
		System.out.println("Main method started");
		
		// static regular method call
	        m1();               //methodname();
	        m1();
	        m1();
	        m1();
	        m1();
		     m2();              //methodname();
		
		System.out.println("Main method ended");	
	}
	
	 //Static regular method
	public static void m1() 
	{
				
	System.out.println("Static regular method is running from same class: m1");
		
	}
	
	// static regular method
	
	 public static void m2() 
	 {
	 System.out.println("Static regular method is running from same class: m2");
	 }
	
	
	
	
}
