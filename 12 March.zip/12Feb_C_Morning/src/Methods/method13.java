package Methods;

public class method13 
{

	//non-static regular method
	
	
	public void studentname(String Sname) 
	{
		System.out.println(Sname);
		
	}
	
	
	
}
