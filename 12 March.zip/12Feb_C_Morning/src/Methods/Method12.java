package Methods;

public class Method12 
{
	public static void main(String[] args) 
	{
		StudentInfo("Vikas", 10, 'A', 65.5f);
		System.out.println("-------------------------");
		StudentInfo("Kavita", 20, 'B', 60.2f);
		
		
		
		// create object of different class
	         method13 P1=new method13();
	         
	         // call the method
	         P1.studentname("Vishwambhar");
	         
		
		
	}

	//Static regular method------>With parameter method----> String, int, char, float
		public static void StudentInfo(String Sname,int Srollno, char Sgrade, float Spercentage) 
		{
			
			System.out.println("Student name:"+Sname);
			System.out.println("Student roll no:"+Srollno);
			
			System.out.println("Student grade: "+Sgrade);
			System.out.println("Stdent percentage :"+Spercentage);
			
		}
	
	
	
	
	
	
	
}
