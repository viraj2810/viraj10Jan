package Methods;

public class Method11 
{
	
	public static void main(String[] args) 
	{
		
		Studentname("Rohit");
		Studentname("Mohit");
		Studentname("Virat");
		
	}

	//Static regular method------>With parameter method----> String parameter
		public static void Studentname(String Sname) 
		{
			System.out.println(Sname);
		}
	

}
