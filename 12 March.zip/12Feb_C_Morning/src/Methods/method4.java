package Methods;

public class method4
{

	   //Static regular method
	
		public static void m4() 
		{
			 System.out.println("Static regular method is running from different class: m4");
			
		}
	
	
	
	
	
	
}
