package Abstract_class;

public class complete_class
{
	//complete methods
   public void m1()             //method declartion
   {
	   System.out.println("Hi"); //method defination
   }
	
  //complete methods
   public void m2()             //method declartion
   {
	   System.out.println("Hello"); //method defination
   }
	
   
   
   
}
