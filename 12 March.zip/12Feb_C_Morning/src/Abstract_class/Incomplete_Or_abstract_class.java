package Abstract_class;

 abstract public class Incomplete_Or_abstract_class 
{
	  
	     int b;
	 
	//complete method
	public void m1()                     //method declartion
	{
		System.out.println("Method m1 is completed in an abstract class"); //method defination
	}
	
	//incomplete method/abstract method
	 abstract public void m2();             //method declartion
	 
	//incomplete method/abstract method
	 abstract public void m3();             //method declartion

	
	
	 
	 
	 
	 
}
