package Abstract_class;

public class sample1 
{
	public static void main(String[] args) 
	{
		
		Concrete_class C1=new Concrete_class();
		
		C1.m1();
		C1.m2();
		C1.m3();
		
		
		
		
		
	}
	
	

}
