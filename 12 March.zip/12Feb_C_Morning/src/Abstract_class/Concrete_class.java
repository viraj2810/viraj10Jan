package Abstract_class;

public class Concrete_class extends Incomplete_Or_abstract_class
{

	   //Completed method
		 public void m2()               //method declartion
		 {
			 System.out.println("Method m2 is completed in concrete class");  //method defination
		 }          
		 
		//Completed method
		 public void m3()        //method declartion
		 {
			System.out.println("Method m3 is completed in concrete class"); //method defination
		 }           

	
	
	
	
}
