package this_and_super_keyword;

public class sample3 
{ //super class

	 int a=30;
	
	
	
	
	
}
