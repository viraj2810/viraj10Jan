package Interface;

public class sample4 
{
	
	public static void main(String[] args) 
	{
		
		Implementation_Class I1=new Implementation_Class();
		    I1.m1();
		    I1.m2();
		
		
	}
	
	
	
	

}
