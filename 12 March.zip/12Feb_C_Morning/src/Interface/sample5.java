package Interface;

public class sample5 
{
  public static void main(String[] args)
  {
	
	  Implementationclass V1=new Implementationclass();
	  
	  V1.m1();
	  V1.m2();
	  V1.m3();
	  V1.m4();
	  
	  
 }
	
	
}
