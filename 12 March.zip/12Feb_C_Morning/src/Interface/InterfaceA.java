package Interface;

public interface InterfaceA 
{

	   void m1();          //abstract public void m1();
	
	
	   void m2();         //abstract public void m2();
	   
}
