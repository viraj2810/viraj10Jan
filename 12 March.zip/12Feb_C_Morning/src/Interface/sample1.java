package Interface;

public class sample1 
{

	public static void main(String[] args) 
	{
		int a=20;                          //Initilisation
		System.out.println(a);
		
		  a=30;                          //Reinitilisation
		System.out.println(a);
		
		a=40;
		System.out.println(a);
	}
	
	
	
	
}
