package Interface;

public class Implementationclass implements InterfaceA, InterfaceB
{

	  public void m1() 
	  {
		  System.out.println("Hi");
	  }          

	   public void m2() 
	   {
		   System.out.println("Hello");  
	   }  
	
	   public void m3() 
	   {
		   System.out.println("Good morning");  
	   }  
	
	   public void m4() 
	   {
		   System.out.println("Good Night");  
	   }  
	
	
	

}
