package Interface;

public class sample3 
{

	public static void main(String[] args) 
	{
		
	}
	
	
	
}
