package Interface;

public class Implementation_Class implements Interface1
{
	//completed method
	public void m1()        // Method declartion
	{
	System.out.println("Method m1 completed in Implementation class");	 //method defination
	}       
		//Completed method
    public void m2()    //method declartion
    {
    	System.out.println("Method m2 completed in Implementation class");	 //method defination	
    }
     
	
	
	
	

}
