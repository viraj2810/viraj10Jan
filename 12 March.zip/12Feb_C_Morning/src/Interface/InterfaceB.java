package Interface;

public interface InterfaceB 
{

	   void m3();          //abstract public void m3();
	
	
	   void m4();         //abstract public void m4();
	   
}
	
	
	


