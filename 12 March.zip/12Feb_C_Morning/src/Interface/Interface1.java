package Interface;

public interface Interface1 
{
        //super interface
	       int a=10;        //final static int a=10;
	
	      void m1();        //abstract public void m1();
	
	      void m2();     //abstract public void m2();
	      
	     
	      
}
