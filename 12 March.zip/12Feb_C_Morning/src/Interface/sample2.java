package Interface;

public class sample2 
{
  public static void main(String[] args)
  {
	    final int a=20;                          //Initilisation
		System.out.println(a);
		
		
	  
 }
	
	
	
	
	
	
	
}
