package Array;

public class chardeclation 
{
	
	public static void main(String[] args) 
	{
		//Array Declartion and Initilasation
		
		char[] Z={'A','B','C','D'};
		
		//usage
		
		for(int i=0; i<=Z.length-1;  i++) 
		{
			System.out.println(Z[i]);
		}
		
	}
	
	
	
	

}
