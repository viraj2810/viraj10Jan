package Array;

public class Intarraydeclaration1 
{
	
	public static void main(String[] args) 
	{
		
		//Array Declartion and Initilasation
		
		int[] ar1= {300,100,200,500,400};
		
		//usage
		
		for(int i=0;   i<=ar1.length-1;  i++  ) 
		{
			System.out.println(ar1[i]);
		}
		
		
	}
	
	
	
	
	
	

}
