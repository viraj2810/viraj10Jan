package Array;

public class Intarray1 
{
   public static void main(String[] args) 
   {
	
	   // Array declartion
	      int[] ar=new int[5];
	     
	   //Array Initilisation
	      ar[0]=300;
	      ar[1]=100;
	      ar[2]=200;
	      ar[3]=500;
	      ar[4]=400;
	      
	   
	   //Usage
	   
	   System.out.println(ar[0]);  //300
	   System.out.println(ar[1]);//100
	   System.out.println(ar[2]);//200
	   System.out.println(ar[3]);//500
	   System.out.println(ar[4]);//400
	   
   }
	
	
	
}
