package Array;

public class Stringdeclaration
{

	public static void main(String[] args) 
	{
		   //Array Declartion and Initilasation
		
		String[] A= {"Rohit", "Virat", "Rahul","MSD"};
		
		//Usage
		
		for(int i=0; i<=A.length-1; i++)
		{
			System.out.println(A[i]);
		}
		
		
	}
	
	
	
	
	
	
	
	
}
