package Array;

public class chararray1 
{
	
	public static void main(String[] args)
	{
		//Array declartion
		
	   char[] B1=new char[4];
		
		//Array Initlisation
	         B1[0]='A';
	         B1[1]='B';
		     B1[2]='C';
		     B1[3]='D';
		     
		 //Usage
		     
		     for(int i=0;  i<=B1.length-1; i++) 
		     {
		    	 System.out.println(B1[i]);
		     }
		     
		     
		     
	}
	
	
	
	
	

}
