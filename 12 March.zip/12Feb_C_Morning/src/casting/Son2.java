package casting;

public class Son2 extends Father2
{
	
	// Sub class
	
	public void Mobile() 
	{
	  System.out.println("Samung A50");
	}
	
	public void car() 
	{
		System.out.println("Car:BMW");
	}
	
	public void Money() 
	{
		System.out.println("Money:10Lakh");
	}
	

}
