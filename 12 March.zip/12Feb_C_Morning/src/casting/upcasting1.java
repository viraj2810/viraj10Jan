package casting;

public class upcasting1 
{
	
	public static void main(String[] args) 
	{
		//Create object of sub-class & provide reference of superclass
		
		Father1 S1=new Son1();
		S1.car();
		S1.Home();
		S1.Money();
	
		
	}
	
	
	
	

}
