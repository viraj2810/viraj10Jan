package casting;

public class Son1 extends Father1
{
	// Sub class
	
		public void Mobile() 
		{
			System.out.println("Samung A50");
		}

		public void Bike() 
		{
			System.out.println("Unicorn");
		}

		public void car() 
		{
			System.out.println("Car:Kia seltos");
		}
		
		public void Home() 
		{
			System.out.println("Home:3 BHK");
		}
		
		public void Money() 
		{
			System.out.println("Money:2 Lakh");
		}
		
		
		
		
		
		
}
