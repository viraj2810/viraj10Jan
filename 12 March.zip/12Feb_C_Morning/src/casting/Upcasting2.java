package casting;

public class Upcasting2 
{
	public static void main(String[] args) 
	{
		
		//Create object of sub-class & provide reference of superclass
		
	       Father2 S2=new Son2();
	        S2.car();
	        S2.Home();
		    S2.Money();
		    
		
		
	}
}
