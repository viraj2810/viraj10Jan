package Basic;

public class sample1 
{
     // Class Body
	
	public static void main(String[] args) 
	{
		//main Method body
		
		System.out.println("Good Morning");         //printing statement
		
		
		
	}
	
	
	

	
}
