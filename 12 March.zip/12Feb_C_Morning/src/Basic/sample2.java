package Basic;

public class sample2 
{
   //Class Body
	
	
	public static void main(String[] args) 
	{
		// main method Body
		
		System.out.println("Hi");              // printing statement
		
		System.out.println("Hello");            // printing statement
		
		System.out.println("good evening");       // printing statement
		
		
		
	}
	
	
	

	
	
	
	
}
