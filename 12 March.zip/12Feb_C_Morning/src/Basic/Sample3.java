package Basic;

public class Sample3 
{
   // Class Body
	
	public static void main(String[] args)
	{   // Main Method body
		
		
        System.out.println("hello");              //printing statement
		
		System.out.println("hello");            //printing statement
		
		System.out.println("hello");            //printing statement
		
		
	}
	
	
	

	
}
