package Open_Browser;

import org.openqa.selenium.chrome.ChromeDriver;

public class Lauch_browser 
{
   public static void main(String[] args) 
   {
	
	   System.setProperty("webdriver.chrome.driver", 
			   "C:\\Users\\samsung\\Desktop\\selenium-II\\Browser\\chromedriver_win32 (1)\\chromedriver.exe");
	   
	   
	   ChromeDriver driver=new ChromeDriver();
	   
	
	   
   }
	
	
	
	
	
	
}
