package Screenshot;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Screenshot2 
{
	public static void main(String[] args) throws InterruptedException, IOException 
	{
		  // Step-I: Set path of chromedriver.exe file
		  //Parameter-I: Name of the browser
		  //Parameter-II: Path of chromedriver.exe file
		  System.setProperty("webdriver.chrome.driver", 
				  "C:\\Users\\samsung\\Desktop\\selenium-II\\Browser\\chromedriver_win32 (1)\\chromedriver.exe");
		  
		  
		  //Create object of chromedriver class and provide reference of  Webdriver interface             
		            WebDriver driver=new ChromeDriver();
		  
		// To enter URL on the browser/To open an application
		           driver.get("https://www.facebook.com/");
		           
		         
		           //Take Screenshot  
		    File Src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		           
		                 //Create object of File
		      File dest=new File("C:\\Users\\samsung\\Desktop\\selenium-II\\Screenshot\\Sample2.jgp");
		    
		    //Copy screenshot to destination folder
		           FileHandler.copy(Src, dest);
		           
	}
	
	
	
	
	
	
}
