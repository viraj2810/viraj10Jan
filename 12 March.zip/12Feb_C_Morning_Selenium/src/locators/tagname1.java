package locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class tagname1 
{

	public static void main(String[] args) 
	{
		 // Step-I: Set path of chromedriver.exe file
		  //Parameter-I: Name of the browser
		  //Parameter-II: Path of chromedriver.exe file
		  System.setProperty("webdriver.chrome.driver", 
				  "C:\\Users\\samsung\\Desktop\\selenium-II\\Browser\\chromedriver_win32 (1)\\chromedriver.exe");
		  
		  
		  //Create object of chromedriver class and provide reference of  Webdriver interface
		                    
		            WebDriver driver=new ChromeDriver();
		  
		       driver.get("file:///C:/Users/samsung/Desktop/Automation/html%20coding/tagname.html");
	
		       //Enter UN	       
		    driver.findElement(By.tagName("input")).sendKeys("abc");
	
		    //enter Password
		    driver.findElement(By.tagName("input")).sendKeys("xyz");
		    
	}
	
}
