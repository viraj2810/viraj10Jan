package Return_type;

public class Returntype1 
{

	public static void main(String[] args) 
	{
		
		addition(10,20);
		
		
		
	}
	
	public static void addition(int a, int b) 
	{
		        int Sum=a+b;
		        System.out.println(Sum);
	}
	
	
	
	
	
	
}
