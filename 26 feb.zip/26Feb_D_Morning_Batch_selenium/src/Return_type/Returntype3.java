package Return_type;

public class Returntype3 
{

	public static void main(String[] args) 
	{
		String Str1="velocity";
		
		String Str2=covertstring(Str1); //velocity
		
		System.out.println(Str2);
		
		
	}
	
	public static String covertstring(String S1) //velocity
	{   
		       String S2=S1.toUpperCase();   //VELOCITY
		       
		       return S2;//VELOCITY
		
	}
	
	
	
	
	
}
