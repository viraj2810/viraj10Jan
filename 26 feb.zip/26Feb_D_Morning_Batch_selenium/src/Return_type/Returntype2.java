package Return_type;

public class Returntype2 
{
	public static void main(String[] args) 
	{
		
		int Num1=addition(10,20);
		System.out.println(Num1);//30
		
		int Num2=20;
		System.out.println(Num1*Num2);
		
	}
	
	public static int addition(int a, int b) 
	{
		        int Sum=a+b;//30
		       
		        return Sum;//30
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
