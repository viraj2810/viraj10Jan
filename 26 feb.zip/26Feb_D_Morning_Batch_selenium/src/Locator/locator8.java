package Locator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class locator8 
{
	
	public static void main(String[] args) 
	{
		//Parameter-I:Name of the browser
		//Parameter-II:Path of the chromedriver.exe file
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\samsung\\Desktop\\Selenium-I\\chromedriver_win32 (1)\\chromedriver.exe");
		
		
		//create object of chromedriver class by providing reference of the webdriver
	           WebDriver driver=new ChromeDriver();
	                    
	              //To enter URL on the webpage/to open an application
	           driver.get("https://www.facebook.com/");
	           
	           //click on forgotton paswword link
	     driver.findElement(By.xpath("//a[contains(text(),' password')]")).click();
	   
	}
	                    
	           	
	
	
	
	
	
	
	
	

}
