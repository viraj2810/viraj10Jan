package Locator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class locator10 
{

	public static void main(String[] args) throws InterruptedException 
	{
		//Parameter-I:Name of the browser
		//Parameter-II:Path of the chromedriver.exe file
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\samsung\\Desktop\\Selenium-I\\chromedriver_win32 (1)\\chromedriver.exe");
		
		
		//create object of chromedriver class by providing reference of the webdriver
	           WebDriver driver=new ChromeDriver();
	                    
	              //To enter URL on the webpage/to open an application
	           driver.get("https://www.facebook.com/");
	           
	          //click on create new account button
	            driver.findElement(By.xpath("//a[text()='Create New Account']")).click();
	           
	          //wait
	            Thread.sleep(1000);
	            
	           //enter mobile no or email address 
	        driver.findElement(By.xpath("(//input[@type='text'])[4]")).sendKeys("9876543210");      
	                    
	}
	
	
	
	
	
	
	
}
