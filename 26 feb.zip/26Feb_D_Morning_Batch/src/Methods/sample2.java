package Methods;

public class sample2 
{   //static regular method call from same class
	public static void main(String[] args) 
	{
		System.out.println("Main method started");
		
			m2();	                           //methodname();
			m3();                             //methodname();
		System.out.println("Main method ended");	
	}
	
	//static regular method 
		public static void m2() 
		{
			System.out.println("Good Evening");	
		}
		
		//static regular method 
		public static void m3() 
		{
			System.out.println("Good Night");	
		}
		
	
	
	
}
