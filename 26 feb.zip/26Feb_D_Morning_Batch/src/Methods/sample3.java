package Methods;

public class sample3 
{

	//static regular method call from same class
	public static void main(String[] args) 
	{
			m2();	                           //methodname();
			m3();                             //methodname();
			
	}
	
	//static regular method 
		public static void m2() 
		{
			System.out.println("Good Evening");	
		}
		
		//static regular method 
		public static void m3() 
		{
			System.out.println("Good Night");	
		}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
