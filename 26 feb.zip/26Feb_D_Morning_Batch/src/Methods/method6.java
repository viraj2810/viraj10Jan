package Methods;

public class method6 
{

	//non-static regular method
	public void m7() 
	{
		System.out.println("Good afternoon");
	}
	
	
	//non-static regular method
	public void m8() 
	{
		System.out.println("Good Night");
	}
		
	
	
	
}
