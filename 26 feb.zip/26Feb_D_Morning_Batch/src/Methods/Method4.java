package Methods;

public class Method4 
{
	
	//non-static regular method call from same class
		public static void main(String[] args) 
		{
			//create object of same class
			Method4 S2=new Method4();       //classname objectname=new classname();
			//call the methods
			    S2.m4();                //objectname.methodname();
			    S2.m5();                //objectname.methodname();
			    S2.m6();                //objectname.methodname();
			    
			   
			    
		}
		
		
		//non-static regular method
		public void m4() 
		{
			System.out.println("Good morning");
		}
		
		//non-static regular method
		public void m5() 
		{
			System.out.println("Good Evening");
		}
	
		//non-static regular method
		public void m6() 
		{
			System.out.println("Good Night");
		}
	
	
	
	
	

}
