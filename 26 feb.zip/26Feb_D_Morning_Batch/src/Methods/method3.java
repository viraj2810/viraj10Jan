package Methods;

public class method3 
{
	//non-static regular method call from same class
	public static void main(String[] args) 
	{
		System.out.println("Main method started");
		
		//Step-I: create object of same class
		    method3 S1 =new method3();                  //classname objectname=new classname();
		  //Step-II: call the method
		    S1.m1();                                      //objectname.methodname();
		    
		System.out.println("Main method ended");
		
	}
	
	
	//non-static regular method
	public void m1() 
	{
		System.out.println("hi");
	}
	
	
	
	
	

}
