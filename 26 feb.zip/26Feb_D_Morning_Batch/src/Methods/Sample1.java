package Methods;

public class Sample1 
{    // class body
	 //static regular method call from same class
	public static void main(String[] args) 
	{   //main method body
		  
		System.out.println("Main method started");
		
		         m1();            //methodname();
		         m1();   
		
		System.out.println("Main method ended");
	
	}
	
	//static regular method 
	public static void m1() 
	{
		System.out.println("Good Morning");	
	}
	
	

}
