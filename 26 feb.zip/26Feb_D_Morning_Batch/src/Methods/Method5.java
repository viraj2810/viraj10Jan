package Methods;

public class Method5 
{
   //non-static regular method call from different class
	public static void main(String[] args)
	{
		
		System.out.println("Main method started");
		
		//Step-I: Create object of different class
		    method6 S6=new method6();                  //classname objectname=new classname();
		   //call the method
		    S6.m7();                                  //objectname.methodname()
		    S6.m8();                                  //objectname.methodname()
		System.out.println("Main method ended");
		
		
		
	}
	
	
	
	
	
	
	
}
