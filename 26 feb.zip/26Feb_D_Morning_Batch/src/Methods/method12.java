package Methods;

public class method12 
{

	public static void main(String[] args) 
	{
		//create object of different class
		method13 S1=new method13();
		//call the method
		S1.m15(20);
		
		//create object of different class
		method12 S2=new method12();
		S2.m16('A');
		
		
		
	}
	
	//non-static regular method
	public void m16(char Z) 
	{
		System.out.println(Z);
	}
	
	
	
}
