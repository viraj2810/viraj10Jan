package Methods;

public class method13 
{

	//non-static regular method
	
	public void m15(int X) 
	{
		System.out.println(X);
	}
	
	
	
	
	
	
}
