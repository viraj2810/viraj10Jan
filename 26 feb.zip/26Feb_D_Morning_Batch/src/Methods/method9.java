package Methods;

public class method9 
{
	public static void main(String[] args) 
	{	 addition();                  //methodname(); 
		 addition();                  //methodname();	 
		 addition(20,50);
		 addition(45,30);
		 addition(100,200);
		 
		 addition(10,20,30);
		 addition(100,200,300);
	}
	
	//Static regular method-->without parameter/Zero parameter	
	public static void addition() {
		//variable declartion and initialization
		       int a=10;
		       int b=20;       
		     int Sum=a+b;  
		     System.out.println(Sum);
	}
	//Static regular method-->with parameter/arguments method---->2 int parameter	
	public static void addition(int c, int d) 
	{              int add=c+d;  
		           System.out.println(add);	           
	}
	
	//Static regular method-->with parameter/arguments method---->3 int parameter	
		public static void addition(int P, int Q,int R) 
		{
			           int sum1=P+Q+R;  
			           System.out.println(sum1);
			           
		}
	
	
}
