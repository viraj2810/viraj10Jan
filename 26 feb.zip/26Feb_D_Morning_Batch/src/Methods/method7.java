package Methods;

public class method7 
{
	public static void main(String[] args) 
	{   //static regular method call from same class
		m10();                                          //methodname();
		
		//non-static regular method call from same class
		//create object of same class
		method7  Z1=new method7();
		     //call the method
		      Z1.m11();                               //objectname.methodname();
		      
    //static regular method call from different class    
		      method8.m12();                          //classname.methodname();  
		
	//non-static regular method call from different class      
		     //create object of different class 
		      method8 Z2=new method8();
		      //call the method
		      Z2.m13();                              //objectname.methodname();
		      
		      
	}
	
	//static regular method 
	public static void m10() 
	{
		System.out.println("Good Morning");	
	}
		
	//non-static regular method
	public void m11() 
	{
		System.out.println("Good Afternoon");
	}
			
	
	
	

}
