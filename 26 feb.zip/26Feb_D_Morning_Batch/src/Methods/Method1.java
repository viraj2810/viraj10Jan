package Methods;

public class Method1 
{

	// static regular method call from different class 
	public static void main(String[] args)       //main method
	{
		
		System.out.println("Main method stared");
		
		    method2.m5();                          //classname.methodname();
		
		
		System.out.println("Main method ended");
		
	}
	
	
	
	
	
	
	
	
}
