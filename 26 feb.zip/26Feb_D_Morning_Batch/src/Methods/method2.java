package Methods;

public class method2 
{

	// static regular method
	
	public static void m5() 
	{
		System.out.println("Good Afternoon");
	}
	
	

	
}
