package Methods;

public class method8 
{

	//static regular method 
		public static void m12() 
		{
			System.out.println("Good Morning");	
		}
			
		//non-static regular method
		public void m13() 
		{
			System.out.println("Good Afternoon");
		}
	
	
	
	
	
}
