package Methods;

public class methods11 
{

	public static void main(String[] args) 
	{	
		Studentinfo("Rahul",50,'A',60.25f);        //methodname();
		
		
	}
	
	//Static regular method-->with parameter---->String,int,char,float parameter	
	
		public static void Studentinfo(String sname,int Srollno,char sgrade,float sper) 
		{
			System.out.println(sname);
			System.out.println(Srollno);
			System.out.println(sgrade);
			System.out.println(sper);
		}
	
	
	
	
	
	
}
