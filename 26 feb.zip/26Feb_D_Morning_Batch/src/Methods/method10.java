package Methods;

public class method10 
{

	public static void main(String[] args) 
	{	
		Studentname("Rohit");                      //methodname();
		Studentname("Virat");

	}
	
	
	//Static regular method-->with parameter---->String parameter	
	
	public static void Studentname(String sname) 
	{
		System.out.println(sname); //Rohit
		
	}
	
	
	
	
	
	
}
