package Polymorphism;

public class Sample4 
{
    public static void main(String[] args)
    {
    	  Sample3 S3=new Sample3();
    	      S3.addition(10, 20);
    	     S3.addition(10, 20, 30);
    	      S3.addition("Virat");
    	      S3.addition(10, 'B');
    	
    	
    	
   }
	
	
	
	
	
	
	
}
