package Polymorphism;

public class Sample1 
{
	public static void main(String[] args) 
	{
	
		
		
		
	}
	
	public void m2()                  //Method declartion
	{
		System.out.println("Hi");    //Method Defination
	}
	
	public static void m1()           //Method declartion
	{
		System.out.println("Hello");   //Method Defination
	}
	
	
	
	
	

}
