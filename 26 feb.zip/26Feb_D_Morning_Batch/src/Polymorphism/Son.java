package Polymorphism;

public class Son extends Father
{
    //sub class
	public void Mobile() 
	{
		System.out.println("Samsung A50");
	}
	
	//Overridden method
	public void car() 
	{
		System.out.println("BMW"); //Method defination
	}
	
	//Overridden method
	public void Money() 
	{
		System.out.println("10 lakhs"); //Method defination
	}
	
	//Overridden method
	public void Home() 
	{
		System.out.println("3 BHK");  //Method defination
	}
	
	
	
}
