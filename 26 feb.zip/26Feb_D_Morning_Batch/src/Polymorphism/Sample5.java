package Polymorphism;

public class Sample5 
{

	public static void main(String[] args) 
	{
	
		Sample5 S5=new Sample5();
		       S5.m1();
		
	}
	
	public void m1()                  //Method declartion
	{
		System.out.println("Hi");    //Method Defination
		System.out.println("Hello Hi");
		System.out.println("Good Morning");
	}
	
	public void m2()                   //Method declartion
	{
		System.out.println("Hello");   //Method Defination
	}
	
	
	
	
	
	
	
	
	

}
