package Polymorphism;

public class Sample3 
{
	
	public void addition(int a, int b) 
	{
		     int c=a+b;
		     System.out.println(c);
		
	}
	
	public void addition(int d, int e,int f) 
	{
		    int Sum=d+e+f;
		  System.out.println(Sum);
	}
	
	public void addition(String Sname)
	{
		System.out.println(Sname);
	}
	
	public void addition(int z, char A) 
	{
		System.out.println(z);
	}
	
	public static void addition(int a) 
	{
		System.out.println(a);
	}
	
	
}
