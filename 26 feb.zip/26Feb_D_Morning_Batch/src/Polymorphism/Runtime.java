package Polymorphism;

public class Runtime 
{
	
	public static void main(String[] args) 
	{
		//Create object of Son class
		
		    Son S1=new Son();
		    S1.Mobile();
		    S1.car();
		    S1.Home();
		    S1.Money();
		
	}
	
	
	
	
	
	

}
