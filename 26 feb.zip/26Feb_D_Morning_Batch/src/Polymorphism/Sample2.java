package Polymorphism;

public class Sample2 
{
	public static void main(String[] args) 
	{
	
		
		
		
	}
	
	public void m1()                  //Method declartion
	{
		System.out.println("Hi");    //Method Defination
	}
	
	public void m2()
	{
		System.out.println("Good Morning");
	}
	
	
	

}
