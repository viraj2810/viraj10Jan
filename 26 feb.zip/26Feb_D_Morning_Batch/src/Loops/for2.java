package Loops;

public class for2 
{

	//Print 10 to 20 nos
	
	public static void main(String[] args)
	{
		    
		for(int i=10;    i<=20;       i++ ) 
		{
			
			System.out.println(i);  
			
		}
		
		
		
		
		
		
	}
	
	
	
	
	
}
