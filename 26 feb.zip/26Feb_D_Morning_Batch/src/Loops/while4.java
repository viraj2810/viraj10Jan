package Loops;

public class while4 
{

	 //Print even no from 100 to 2 
		public static void main(String[] args) 
		{
			  int i=100;                  // Starting condition
			
			    
			while(i>=2)                     //end condition
			{
				System.out.println(i); 
				
			    i=i-2;                     // increment/decrement
				
			}
			
			
		}
		
	
	
	
	
	
	
	
	
}
