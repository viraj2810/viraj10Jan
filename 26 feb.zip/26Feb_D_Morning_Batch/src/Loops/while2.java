package Loops;

public class while2 
{
	       //Print 10 to 20 nos

	public static void main(String[] args) 
	{
		  int i=10;                  // Starting condition
		
		     
		while(i<=20)                     //end condition
		{
			System.out.println(i);  
			
		      i++;        	// increment/decrement
			
		}
		
		
	}
	
	
	
	
	

}
