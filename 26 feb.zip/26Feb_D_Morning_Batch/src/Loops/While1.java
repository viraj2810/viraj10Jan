package Loops;

public class While1 
{
	         //Print 1 to 5 nos
	public static void main(String[] args) 
	{
		  int i=1;  //i=1               // Starting condition
		
		   //6<=5
		while(i<=5)                     //end condition
		{
			System.out.println(i);  //1  2  3   4   5
			
		      i++;  //6         	// increment/decrement
			
		}
		
		
	}

}
