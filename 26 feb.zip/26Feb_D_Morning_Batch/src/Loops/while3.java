package Loops;

public class while3 
{
         //Print 5 to 1 no
	public static void main(String[] args) 
	{
		  int i=5; //i=5                 // Starting condition
		
		     //0>=1
		while(i>=1)                     //end condition
		{
			System.out.println(i);  //5  4  3   2  1
			
		     i--; //0     	// increment/decrement
			
		}
		
		
	}
	
	
	
	
	
	
	
}
