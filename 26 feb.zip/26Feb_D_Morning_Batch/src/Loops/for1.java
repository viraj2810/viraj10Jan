package Loops;

public class for1 
{
         //Print 1 to 5 nos
	public static void main(String[] args) 
	{
		  //i=1       //1<=5       2
		              //2<=5       3
		              //3<=5       4
		              //4<=5       5
		              //5<=5       6
		              //6<=5
		for(int i=1;  i<=5;       i++) 
		{
			
			System.out.println(i);  //1  2   3   4    5
			
		}
		
		
		
		
	}
	
	
	
	
	
	
}
