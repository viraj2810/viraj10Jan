package Types_of_variables;

public class static_diff1 
{

	//static global variable call from different class
	public static void main(String[] args) 
	{
		System.out.println(static_diff2.b);  //classname.variablename
	
	}
		
	
}
