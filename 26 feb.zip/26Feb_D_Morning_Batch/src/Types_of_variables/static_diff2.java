package Types_of_variables;

public class static_diff2
{

	   static int b=40;                     // static global variable
	
	
}
