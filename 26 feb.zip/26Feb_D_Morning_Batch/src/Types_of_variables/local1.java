package Types_of_variables;

public class local1 
{
	public static void main(String[] args) 
	{
		M1(10);
					
	}
	
	public static void M1(int a)   // local variable
	{
		int b=20;                  // local variable
		System.out.println(b);
		int c=40;                 // local variable
		System.out.println(c);
		
		System.out.println(a);
	}
	
	public static void M2() 
	{
		
	}
	
	

}
