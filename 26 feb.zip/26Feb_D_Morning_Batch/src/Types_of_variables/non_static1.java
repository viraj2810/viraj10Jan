package Types_of_variables;

public class non_static1 
{  //non-static/instance global variable call from same class
        int d=20;              //non-static/instance global variable
	
    public static void main(String[] args) 
	{
		//create object of same class
    	non_static1 V1= new non_static1();
    	//call the variable
    	System.out.println(V1.d);  //objectname.variablename
    	
    	       V1.M6();
		
	}
	
	public static void M5()   
	{
		
	}
	
	public void M6() 
	{
		System.out.println(d);
	}
	
	
}

