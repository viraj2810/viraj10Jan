package Types_of_variables;

public class non_static_diff2 
{

	
	     int Z=50;             //non-static/instance global variable 
	
	
	
	
}
