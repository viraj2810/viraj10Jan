package Types_of_variables;

public class staticglobal1 
{ 
	// Static/class global variable call from same class
      static int a=60;                     //static/class global variable
	
	public static void main(String[] args) 
	{
		System.out.println(a);	            //variablename	
		M3();                              //methodname();
		
		staticglobal1 S1=new staticglobal1();
	      	S1.M4();
	}
	
	public static void M3() 
	{
		System.out.println(a);
	}
	
	public void M4() 
	{
		System.out.println(a);
	}
	
	
	
	
	
}
