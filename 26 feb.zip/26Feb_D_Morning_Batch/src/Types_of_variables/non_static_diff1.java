package Types_of_variables;

public class non_static_diff1 
{
	//non-static/instance global variable call from different class
	public static void main(String[] args) 
	{
		//create object of different class
		non_static_diff2 V2=new non_static_diff2();
		//call the variable
		System.out.println(V2.Z);        //objectnamename.variablename
		
		
	}
	
	

	
}

