package Access_Specifier;

public class Sample4
{

	public static void main(String[] args) 
	{
		 Sample3 S3=new Sample3();
		  
		
		
	}
	
	
	
	
	
}
