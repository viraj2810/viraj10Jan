package Access_Specifier;

public class Sample1 
{
	   public int a=10;
	
    public static void main(String[] args)
    {
		
    	Sample5 S5=new Sample5();
    	S5.m4();
    	
    	System.out.println(S5.a);
    	
	}

    public void m1() 
    {
    	System.out.println("Hi");
    }
    
    public void m2() 
    {
    	System.out.println("Hello");
    }
    
    
	
}
