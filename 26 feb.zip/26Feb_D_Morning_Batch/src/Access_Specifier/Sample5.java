package Access_Specifier;

public class Sample5 
{
           int a=50;
	public static void main(String[] args) 
	{
		Sample5 S5=new Sample5();
		    S5.m4();
		System.out.println( S5.a);
		
	}
	
	  void m4() 
	  {
		  System.out.println("Good Evening"); 
	  }
	
	
	
	
	
	
	
	
	
}
