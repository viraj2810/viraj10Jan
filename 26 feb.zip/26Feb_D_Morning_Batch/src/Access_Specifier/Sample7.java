package Access_Specifier;

public class Sample7 
{
	
	public static void main(String[] args)
	{
		Sample6 S6=new Sample6();
		S6.m1();
		S6.m2();
		System.out.println(S6.a);
		
		
		
	}
	

}
