package Access_Specifier;

public class Sample3 
{
      private  int a=20;
	public static void main(String[] args) 
	{
		Sample3 S3=new Sample3();
			S3.m3();
			
			System.out.println(S3.a);
			
		
	}
	
	private void m3() 
	{
		System.out.println("Good morning");
	}
	
	
	
	
	
	
	
	
}
