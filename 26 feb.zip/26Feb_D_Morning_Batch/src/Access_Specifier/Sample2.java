package Access_Specifier;

public class Sample2 
{

	public static void main(String[] args) 
	{
		
		Sample1 S1=new Sample1();
		   S1.m1();
		
		System.out.println(S1.a);
		
	}
	
	
	
}
