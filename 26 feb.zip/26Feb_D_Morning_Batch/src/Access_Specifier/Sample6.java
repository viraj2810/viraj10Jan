package Access_Specifier;

public class Sample6 
{
	
	protected int a=10;
		
	 public static void main(String[] args)
	{
		 Sample6 S6=new Sample6();
		 S6.m1();
		 S6.m2();
	    System.out.println(S6.a);	
		 
	}

	  protected void m1() 
	    {
	    	System.out.println("Good night");
	    }
	    
	  protected void m2() 
	    {
	    	System.out.println("Good morning");
	    }
	    
	
	
	
	

}
