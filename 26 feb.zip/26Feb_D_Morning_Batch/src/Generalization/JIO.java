package Generalization;

public class JIO implements Simcard
{   //Implementation class
	
	public void SMS() 
	{
		System.out.println("100");
	}
	
   public void AudioCalling() 
   {
	   System.out.println("Unlimited");
   }

   public void Internet() 
   {
	   System.out.println("1.5 GB");
   }
	
	
	
	

}
