package Generalization;

public class Airtel implements Simcard
{  //Implementation class

    public void SMS()
    {
    	System.out.println("1000 SMS");
    }
	
   public void AudioCalling() 
   {
	   System.out.println("500 Minutes");
   }

   public void Internet() 
   {
	   System.out.println("2 GB");
   }
	
	
	
	
	
	
	
	
	
	
}
