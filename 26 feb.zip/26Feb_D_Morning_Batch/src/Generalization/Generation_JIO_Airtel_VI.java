package Generalization;

public class Generation_JIO_Airtel_VI 
{
	
	public static void main(String[] args) 
	{
		//Create object of JIO class
		JIO S1=new JIO();
		S1.SMS();
		S1.AudioCalling();
		S1.Internet();
		
		//Create object of Airtel class
		Airtel A1=new Airtel();
		A1.SMS();
		A1.AudioCalling();
		A1.Internet();
		
		//Create object of VI class	
		   VI V1= new VI();
		     V1.SMS();
		     V1.AudioCalling();
		     V1.Internet();
		
		
	}
	
	
	
	
	
	
	

}
