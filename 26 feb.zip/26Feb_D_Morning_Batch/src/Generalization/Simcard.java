package Generalization;

public interface Simcard 
{    // Super Interface

	       void SMS();
	
	       void AudioCalling();
	
	       void Internet();
	
	
}
