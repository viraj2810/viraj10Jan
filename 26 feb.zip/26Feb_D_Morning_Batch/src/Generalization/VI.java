package Generalization;

public class VI implements Simcard
{
	 //Implementation class

   public void SMS() 
   {
	   System.out.println("500 SMS");
   }

   public void AudioCalling()
   {
	   System.out.println("1000 Minutes");
   }

   public void Internet()
   {
	   System.out.println("3 GB");
   }

	
	
	
	
	
	
	
	
	
	
}
