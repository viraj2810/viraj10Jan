package This_and_super_Keyword;

public class Demo1 extends Demo2
{
	//Sub class
	//  int a=60;
	
	   int a=20;
	  int b=30;
	  
	public void m1() 
	{
		int a=10;                       // Local variable
		System.out.println(a); //10
		
	   System.out.println(a); //10
		
	   System.out.println(b); //30
	   
	   System.out.println(this.a);  //20       //this.variablename
	   
	   System.out.println(this.a);  //20
	   
	   System.out.println(super.a);  //60     //super.variablename
	   
	}
	
	public static void main(String[] args) 
	{
		Demo1 D1=new Demo1();
		  D1.m1();
		
		
	}
	
	
	
	
	
	
	
	
}
