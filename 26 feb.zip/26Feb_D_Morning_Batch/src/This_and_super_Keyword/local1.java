package This_and_super_Keyword;

public class local1 
{
	public void m1() 
	{
		int a=10;              // Local variable
		System.out.println(a); //10
		
		int d=50;             // Local variable
		System.out.println(d); //50
		
	}
	
	public static void main(String[] args) 
	{
		local1 V1=new local1();
		   V1.m1();
		
		
	}
	
	
	

}
