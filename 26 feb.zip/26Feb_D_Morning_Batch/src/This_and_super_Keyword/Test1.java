package This_and_super_Keyword;

import Access_Specifier.Sample1;
import Access_Specifier.Sample5;
import Access_Specifier.Sample6;

public class Test1 extends Sample6 
{
	
	public static void main(String[] args) 
	{
		
	     Sample1 S1=new Sample1();
		        S1.m1();
		        S1.m2();
		
		System.out.println(S1.a);
		
		
		Test1 T1=new Test1();
		T1.m1();
		T1.m2();
		
		System.out.println(T1.a);
		
		
	}
	
	
	
	
	
	

}
