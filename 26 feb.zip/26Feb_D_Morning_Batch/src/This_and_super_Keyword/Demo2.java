package This_and_super_Keyword;

public class Demo2
{
    //Super class
	
	//global varible
	
	  int a=60;
	
	
	
	
	
	
}
