package Interface;

public class Implementation_Class implements InterfaceA, InterfaceB
{
	
	  public void m1() 
	  {
		System.out.println("M1 Method is completed in Implementation class");  
	  }
		
     public void m2() 
     {
    	 System.out.println("M2 Method is completed in Implementation class");
     }

     public void m3() 
      {
    	 System.out.println("M3 Method is completed in Implementation class");
      }
		
     public void m4() 
     {
    	 System.out.println("M4 Method is completed in Implementation class"); 
     }

	
	
	
	
	

}
