package Interface;

public class Implementationclass1 implements Interface1
{

	     
	
		public void m1() 
		{
		 System.out.println("M1 Method is completed in Implementation class1");	
		}    
		
       public void m2() 
      {
    	System.out.println("M2 Method is completed in Implementation class1");  
      }
	
       public static void main(String[] args) 
       {
		
    	   System.out.println(a);
	
       }
	
	
	
	
	
	
}
