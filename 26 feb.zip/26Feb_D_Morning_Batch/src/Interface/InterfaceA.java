package Interface;

public interface InterfaceA 
{

	      void m1();
	
	      void m2();
	
	
	
	
}
