package Interface;

public class sample2 
{

	public static void main(String[] args) 
	{
		
		Implementation_Class S1=new Implementation_Class();
		S1.m1();
		S1.m2();
		S1.m3();
		S1.m4();
		
		
	}
	
	
	
	
	
	
	
	
}
