package Interface;

public interface InterfaceB 
{
	
	 void m3();
		
     void m4();



}
