package Interface;

public class sample1 
{
	
	public static void main(String[] args) 
	{
		
		Implementationclass1 S1=new Implementationclass1();
		
			S1.m1();
			S1.m2();
	}
	
	
	

}
