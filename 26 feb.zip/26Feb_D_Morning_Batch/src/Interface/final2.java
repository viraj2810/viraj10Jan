package Interface;

public class final2 
{

	public static void main(String[] args)
	{
	    final int b=50;
		
		System.out.println(b);
		
		
	
	
	
	
	
	}
	
}
