package Interface;

public class final1 
{

	public static void main(String[] args)
	{
		//variable declartion abd initlisation
		   int b=20;
		    System.out.println(b);
		
		     b=25;                    //reinitilisation
		System.out.println(b);
		
		  b=10;                      //reinitilisation
		System.out.println(b);
		
		b=500;                      //reinitilisation
		System.out.println(b);
		System.out.println(b);
		
	}
	
	
	
	
	
	
}
