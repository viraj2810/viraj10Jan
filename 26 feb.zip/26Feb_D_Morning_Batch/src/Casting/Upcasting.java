package Casting;

public class Upcasting 
{

	public static void main(String[] args) 
	{
		// Create object of sub-class class by providing reference of Super class
		
		      Father S1=new Son();
		         S1.car();
		         S1.Home();
		         S1.Money();
		
		
		
		
		
		
	}
	
	
	
	
	
}
