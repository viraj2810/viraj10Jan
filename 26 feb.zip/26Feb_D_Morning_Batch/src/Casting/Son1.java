package Casting;

public class Son1 extends father1
{
    //Sub class
	public void Mobile() 
	{
		System.out.println("Samsung");
	}
	
	
	public void Bike() 
	{
		System.out.println("Unicorn");
	}
	
	
	public void car() 
	{
		System.out.println("Skoda");
	}
	
	
	public void Money() 
	{
		System.out.println("10 lakhs");
	}
	
	
	
	
	
	

}
