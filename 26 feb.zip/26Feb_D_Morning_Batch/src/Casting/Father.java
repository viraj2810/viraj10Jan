package Casting;

public class Father 
{
	  //super class
	public void car() 
	{
		System.out.println("Honda City");
	}
	
	
	public void Money() 
	{
		System.out.println("5 lakhs");
	}
	
	public void Home() 
	{
		System.out.println("2 BHK");
	}
	

}
