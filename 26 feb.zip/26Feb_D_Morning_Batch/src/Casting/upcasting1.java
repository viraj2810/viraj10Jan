package Casting;

public class upcasting1 
{
	
	public static void main(String[] args) 
	{
		//Create object of sub-class by providing reference of super class
		
		            father1 S2=new Son1();
		
		            	S2.car();
		            	S2.Home();
		            	S2.Money();
		
		
		            
		            	
		            	
		            	
		
	}
	
	
	
	
	
	

}
