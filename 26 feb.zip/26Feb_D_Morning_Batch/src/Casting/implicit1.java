package Casting;

public class implicit1 
{
	public static void main(String[] args) 
	{
		
		     int a=5;          //4 byte
		System.out.println(a);
		
		    double b=a;     //8 byte
		System.out.println(b);
		
	}
	
	
	
	
	

}
