package Casting;

public class Son extends Father
{
        //Sub class
	public void Mobile() 
	{
		System.out.println("Samsung");
	}
	
	
	public void Bike() 
	{
		System.out.println("Unicorn");
	}
	
	
	public void car() 
	{
		System.out.println("BMW");
	}
	
	public void Money() 
	{
		System.out.println("2 lakhs");
	}
	
	public void Home() 
	{
		System.out.println("3 BHK");
	}
	
	
	
	
	
	
	
}
