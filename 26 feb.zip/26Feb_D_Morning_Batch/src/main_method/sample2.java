package main_method;

public class sample2 extends sample1
{
	
	
	public static void main(String[] args)
	{
		System.out.println("Good morning");
		
		m1();
		
	}
	
	
	public static void m1() 
	{
		System.out.println("Good afternoon");
	}
	
	
	
	
	

}
