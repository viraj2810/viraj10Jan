package main_method;

public class main1 
{
	
	public static void main(String[] args)
	{
		
		int Num1=addition(20,30);
		
		System.out.println(Num1);
		
		
	}
	
	
	
	public static int addition(int a, int b)
	{
		        int sum=a+b;//50
		        
		 return sum;//50
		
	}
	
	
	
	

}
