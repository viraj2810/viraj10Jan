package main_method;

public class main_method_overloading1 
{

	public static void main(String[] args)
	{
		System.out.println("Hi");
	}
	
	
	public static void main(int[] args)
	{
		System.out.println("good morning");
	}
	
	
	public static void main(char[] args)
	{
		System.out.println("Good evening");
	}
	
	
	
}
