package main_method;

public class sample1 
{

	public static void main(String[] args)
	{
		System.out.println("Hi");
		
	
	}
	
	
	public static void m1() 
	{
		System.out.println("Hello");
	}
	
	
	
	
	
	
	
	
}
