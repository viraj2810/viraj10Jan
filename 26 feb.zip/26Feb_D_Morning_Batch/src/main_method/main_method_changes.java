package main_method;

public class main_method_changes 
{

	
	static final strictfp public synchronized void main(String[] args)
	{
		
		System.out.println("Hi");
		
		
		
	}
	
	
	
	
	
	
}
