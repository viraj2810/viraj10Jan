package Constructor;

public class sample9 
{

	public static void main(String[] args) 
	{
		
		Sample8 S8=new Sample8("Virat",105,'A',60.25f);
		   S8.Studentinfo();
		  S8.Studentinfo();
		  S8.Studentinfo();
		  S8.Studentinfo();
		  
		
		Sample8 S9=new Sample8("Rohit",106,'B',70.10f);
		        S9.Studentinfo();
		
	}
	
	
	
	
	
	
	
}
