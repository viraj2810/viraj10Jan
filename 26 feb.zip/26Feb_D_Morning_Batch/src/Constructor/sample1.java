package Constructor;

public class sample1 
{
	//default constructor---->Compiler
	//Use-I: Copies member of class into an object
	//sample1(){}
	
	public static void main(String[] args) 
	{
		//create object of same class
		sample1 S1=new sample1();         //classname objectname=new classname();
		 S1.multiplication();
	
		//create object of different class
		 sample2 S2=new sample2();        //classname objectname=new classname();
		  S2.addition();
		 
		 
	}
	
	public void multiplication() 
	{
		int a=10;
		int b=20;	
		int mulvalue= a*b;
		System.out.println(mulvalue);
	}
	
	
	
	
	
	

}
