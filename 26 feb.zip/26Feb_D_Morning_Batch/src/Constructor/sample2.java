package Constructor;

public class sample2 
{
        //default constructor-->compiler
	//Use-I: Copies member of class into an object
	   //sample2(){}
	public void addition() 
	{
		int a=10;
		int b=20;	
		int sum= a+b;
		System.out.println(sum);
	}
	
	
	
	
	
	
}
