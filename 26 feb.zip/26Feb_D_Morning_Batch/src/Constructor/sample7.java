package Constructor;

public class sample7 
{

	public static void main(String[] args) 
	{
		Sample6 S6=new Sample6(); 
		S6.addition();
		S6.multiplication();
		
		
		Sample6 S7=new Sample6(10,50);
		S7.addition();
		S7.multiplication();
		
		Sample6 S9=new Sample6(50,50);
		S9.addition();
		S9.multiplication();
		
		Sample6 S8=new Sample6("Virat");
		  S8.M1();
		
		
	}
	
	
	
}
