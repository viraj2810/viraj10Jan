package Constructor;

public class sample3 
{
	 //Use-I: Copies member of class into an object
	//Use-II: initialise non-static global variables
	//Step-I: Variable declaration(non-static global variables)
	    int a;  //10
	    int b;  //20
	
	//Step-II: Variable initialzation
	    sample3()                //Without parameter/zero parameter user defined constructor
	    {
	    	a=10;
	    	b=20; 	
	    }
	//Step-III: usage	 
	    public void addition() 
		{
	    	  int Sum=a+b; //10+20
	    	  System.out.println(Sum);	//30
		}
		
	    public void multiplication() 
		{
			   int Mulvalue=a*b;//10*20
			  System.out.println(Mulvalue); //200		   
		}
		
	    
	    
}


