package Constructor;

public class sample4 
{
     
	public static void main(String[] args) 
	{
		//create object of different class
		   sample3 S3=new sample3();
		    S3.addition();
		    S3.multiplication();
			
		
	}
	
	

}
