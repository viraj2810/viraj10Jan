package Constructor;

public class sample5 
{
	
	 //Use-I: Copies member of class into an object
	//Use-II: initialise non-static global variables
	//Step-I: Variable declaration(non-static global variables)
		    int a; 
		    int b;  
	
		//Step-II: Variable initialzation
	
		 sample5()   //Without parameter/zero parameter user defined constructor
		 {
			a=10;
			b=20;
		 }
		 
		 sample5(int c, int d)    //with parameter user defined constructor
		 {
			 
		 }
		 
		 sample5(String sname)     //with parameter user defined constructor
		 {
			 
		 }
		    
	//Step-III: usage	 
	public void addition() 
	{
	int Sum=a+b; 
	 System.out.println(Sum);	
	}
			
	public void multiplication() 
	{
		  int Mulvalue=a*b;
		 System.out.println(Mulvalue); 		   
	}
			  
		    
		    
}
