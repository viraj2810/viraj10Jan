package Constructor;

public class Sample6
{
	 //Use-I: Copies member of class into an object
	//Use-II: initialise non-static global variables
	//Step-I: Variable declaration(non-static global variables)
		    int Num1; //10
		    int Num2; //50
		    String Studentname;//Virat
	
    //Step-II: Variable initialzation	    
	Sample6()
	{
		Num1=5;
		Num2=6;
	}
	
	Sample6(int a, int b)
	{
		Num1=a; //50
		Num2=b; //50
	}
	
	Sample6(String sname)
	{
		Studentname=sname;  //Virat
	}
	
	
	//Step-III: usage	 
	public void addition() 
	{
         int sum=Num1+Num2; //5+6
         
         System.out.println(sum);//11
	}
	
	public void multiplication() 
	{
		int mulvalue=Num1*Num2; //5*6
		System.out.println(mulvalue);//30
	}
	
	public void M1() 
	{
		System.out.println(Studentname);
	}

	
	
}
