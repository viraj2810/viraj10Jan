package Constructor;

public class Sample8
{
      //Step-I: variable declaration
	
	  String studentname;
	  int Studentrollno;
	  char Studentgrade;
	  float  Studentpercentage;
	  
	//Step-II: Variable initialzation	  
	  Sample8(String sname,int srollno, char sgrade, float sper)
	  {
		  studentname =sname;
		  Studentrollno=srollno;
		  Studentgrade=sgrade;
		  Studentpercentage=sper;
	  }
	  
	  //usage 
	 public void Studentinfo()
	 {
		System.out.println(studentname);	
		System.out.println(Studentrollno);
		System.out.println(Studentgrade);
		System.out.println(Studentpercentage);
	 
	 } 
	  
	  
	
}
