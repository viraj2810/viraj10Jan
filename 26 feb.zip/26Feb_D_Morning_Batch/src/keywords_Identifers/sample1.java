package keywords_Identifers;

public class sample1 {

}
