package Control_statements;

public class if1 
{
	//if condition---->1 condition
	public static void main(String[] args)
	{
	    int marks=55;             //staring condition
		
	        //55>=35
		if(marks>=35)                 //end condition
		{
		     System.out.println("Pass");	
		}
		
		
		
		
	}
	
	
	
	
	
}
