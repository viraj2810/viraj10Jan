package Control_statements;

public class nested_if1 
{
	public static void main(String[] args) 
	{	String Username="abc";	
		String Password="xyz";
		
		if("abc"==Username)  //abc==abc 
		{
			System.out.println("Correct Username");
			
			if("xyz1"==Password) //xyz1==xyz
			{
				System.out.println("Correct Password-->Login sucessfull");
			}
			else 
			{
				System.out.println("Wrong Password-->Login failed");
			}
			
		}
		else 
		{
			System.out.println("Wrong username-->login failed");
		}
		
		
		
		
	}
	
	
	
	
	
	

}
