package Control_statements;

public class else_if2 
{
	public static void main(String[] args)
	  {
	     int marks=31;                 //Staring condition
		//31>=65	  
	  if(marks>=65)
	  {
		  System.out.println("Distinction");
	  }
	          //31>=60
	  else if(marks>=60)
	  {
		  System.out.println("First class");  
	  }
	         //31>=55
	  else if(marks>=55)
	  {
		  System.out.println("Higher second class");  
	  }
	        //31>=50
	  else if(marks>=50)
	  {
		  System.out.println("second class");  
	  }
	         //31>=35
	  else if(marks>=35)
	  {
		  System.out.println("Pass");  
	  }
	  else
	  {
		  System.out.println("fail");  
	  }
	  
	  
	 
	  }

	

}
