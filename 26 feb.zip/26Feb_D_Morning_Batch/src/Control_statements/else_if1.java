package Control_statements;

public class else_if1 
{     //else if---->Multiple condition
	  public static void main(String[] args)
	  {
	       int marks=52;                 //Staring condition
		//52>=65	  
	  if(marks>=65)
	  {
		  System.out.println("Distinction");
	  }
	          //52>=60
	  else if(marks>=60)
	  {
		  System.out.println("First class");  
	  }
	         //52>=55
	  else if(marks>=55)
	  {
		  System.out.println("Higher second class");  
	  }
	        //52>=50
	  else if(marks>=50)
	  {
		  System.out.println("second class");  
	  }
	  else if(marks>=35)
	  {
		  System.out.println("Pass");  
	  }
	  else
	  {
		  System.out.println("fail");  
	  }
	  
	  
	 
	  }
}
	
	
	
	
	
	
	
	
	
	
	

