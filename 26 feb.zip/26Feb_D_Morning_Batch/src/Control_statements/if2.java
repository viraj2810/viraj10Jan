package Control_statements;

public class if2 
{
	//if condition---->1 condition
	public static void main(String[] args)
	{
	    int marks=32;             //staring condition
		
	       //32>=35
		if(marks>=35)                 //end condition
		{
		     System.out.println("Pass");	
		}
		
		
		
		
	}
	
	
	
	
	
}
