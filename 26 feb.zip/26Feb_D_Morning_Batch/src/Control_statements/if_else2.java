package Control_statements;

public class if_else2 
{
     	//if else----> 2 condition
	public static void main(String[] args) 
	{
		   int marks=32;                  //starting condition
		  
		   //32>=35
		if(marks>=35)                                 //end condition
		{
			System.out.println("Pass");
		}
		else 
		{
			System.out.println("Fail");
		}
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
}
