package Control_statements;

public class if_else1 
{
    //if else----> 2 condition
	public static void main(String[] args) 
	{
		   int marks=55;                          //starting condition
		  
		   //55>=35
		if(marks>=35)                                 //end condition
		{
			System.out.println("Pass");
		}
		else 
		{
			System.out.println("Fail");
		}
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
}
