package Array;

import java.util.Arrays;

public class Intarray6 
{
	public static void main(String[] args) 
	{
		//Array declartion
		  int[] ar=new int[5];
		
		 //Array Initialisation    
		  ar[0]=300; 
		  ar[1]=200; 
		  ar[2]=100;  
		  ar[3]=500;  
		  ar[4]=400;  
		  
		  //Usage	  
	     Arrays.sort(ar);
	  
	   for(int i=ar.length-1; i>=0 ; i-- ) 
	   {
		   System.out.println(ar[i]);
	   }
	     
	     
	     
	
	}
	
	
	
	
	
	
	
	
	
	
	

}
