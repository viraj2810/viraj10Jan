package Array;

public class StringArray2 
{

	public static void main(String[] args) 
	{
		  //Array declartion	
		String[] ar1=new String[4];
				
		//Array Initilisation
		ar1[0]="Virat";
		ar1[1]="MSD";
		ar1[2]="Rohit";
		
		
		
		//usage
			//i=0    	  0<=3                1
		                //1<=3                2
		                //2<=3                3
		                //3<=3                4
		                //4<=3
		for(int i=0;      i<=ar1.length-1;   i++ ) 
		{
			System.out.println(ar1[i]); //virat MSD Rohit null
		}
		
	
		
	
	}
	
	
	
	
	
	
	
	
	
	
}
