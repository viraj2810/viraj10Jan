package Array;

public class Intarray4 
{
	public static void main(String[] args) 
	{
		
		//Array declartion
		  int[] ar=new int[5];
		
		 //Array Initialisation    
		  ar[0]=300; 
		  ar[1]=200; 
		  ar[2]=100;  
		  ar[3]=500;  

		  //usage
		  //i=0       //0<=4              1
		              //1<=4              2
		             //2<=4               3
		             //3<=4               4
		             //4<=4
		for(int i=0;   i<=ar.length-1;    i++ ) 
		{
			System.out.println(ar[i]);//300 200 100 500 0
		}  
		  
		  
		  
		  
	}
	
	
	
	
	
	
	
	
	

}
