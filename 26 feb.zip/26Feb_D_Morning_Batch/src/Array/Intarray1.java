package Array;

public class Intarray1 
{
	
	public static void main(String[] args) 
	{
		
		//Array declartion
		  int[] ar=new int[5];
		
		 //Array Initialisation    
		  ar[0]=300; 
		  ar[1]=200; 
		  ar[2]=100;  
		  ar[3]=500;  
		  ar[4]=400;
		  
		  //usage
		  System.out.println(ar[0]);//300
		  System.out.println(ar[1]);//200
		  System.out.println(ar[2]);//100
		  System.out.println(ar[3]);//500
		  System.out.println(ar[4]);//400
		  
	}
	
	

}
