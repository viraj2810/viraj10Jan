package Array;

public class chararray3 
{
	

    public static void main(String[] args)
    {
    	
    	 //Array declartion
	     char[] ar2=new char[4];
	
    	//Array initilisation
	     ar2[0]='A';
	     ar2[1]='B';
	     ar2[2]='C';
	    
    	
    	//Usage
	     
	     for(int i=0; i<=ar2.length-1;    i++  ) 
	     {
            System.out.println(ar2[i]);// A B C

	     }
    	
    	
    	
		
	}

	
	
	
	
	
	
	

}
