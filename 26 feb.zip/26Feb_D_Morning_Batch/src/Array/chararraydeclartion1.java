package Array;

public class chararraydeclartion1 
{
	public static void main(String[] args) 
	{
         //Array declartion and initilisation
		 char[] ar2= {'A','B','C','D'};
		
		//usage
		 for(int i=0; i<=ar2.length-1; i++)
		 {
			 System.out.println(ar2[i]);
		 }
		
		
		
		
		
		
		
	}
	
	
	
	

}
