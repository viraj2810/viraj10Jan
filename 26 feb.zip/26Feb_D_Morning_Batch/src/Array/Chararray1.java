package Array;

public class Chararray1 
{
	
	    public static void main(String[] args)
	    {
	    	
	    	 //Array declartion
		     char[] ar2=new char[4];
		
	    	//Array initilisation
		     ar2[0]='A';
		     ar2[1]='B';
		     ar2[2]='C';
		     ar2[3]='D';
	    	
	    	//Usage
		     
		     for(int i=0; i<=ar2.length-1;   i++  ) 
		     {
                System.out.println(ar2[i]);
 
		     }
	    	
	    	
	    	
			
		}
	
	
	

}
