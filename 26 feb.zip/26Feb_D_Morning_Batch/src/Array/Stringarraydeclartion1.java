package Array;

public class Stringarraydeclartion1 
{

	public static void main(String[] args) 
	{
		 //Array declartion and initilisation
		String[] ar1= {"Virat","Rohit","MSD","Rahul"};
		
		//Usage
		
		    //i=0       0<=3             1
		                //1<=3           2
		               //2<=3            3
		                //3<=3           4
		                 //4<=3
		for(int i=0;    i<=ar1.length-1; i++ )
		{
			System.out.println(ar1[i]);  
		}                                
		                                
		                             
	}
	
	
	
	
	
	
	
	
}
