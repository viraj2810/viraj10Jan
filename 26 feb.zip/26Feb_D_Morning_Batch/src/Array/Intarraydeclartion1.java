package Array;

public class Intarraydeclartion1 
{
	public static void main(String[] args)
	{
		
		//Array declaration and initialisation
		    int[] ar= {300,100,200,500,400};
		
		
		//Usage
		    for(int i=0; i<=ar.length-1; i++) 
		    {
		    	System.out.println(ar[i]);
		    }
		
		
		
		    
		    
		    
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
