package Abstract_Class;

public class Sample1 
{

	public static void main(String[] args) 
	{
		Concrete_Class C1=new Concrete_Class();
		   C1.m1();
		   C1.m2();
		   C1.m3();
		
		
		
		
		
		
	}
	
	
	
	
	
}
