package Abstract_Class;

   abstract public class Incompleteclassor_or_Abstractclass
{
	   
	   Incompleteclassor_or_Abstractclass()
	   {
		   
	   } 
	
	   
	   
    // Complete method
	public void m1()          //method declaration
	{
		System.out.println("Hello"); // Method defination
	}
	
	
	//Incomplete or abstract method
	  abstract public void m2();          //method declaration
	
	  
	
	//Incomplete or abstract method
	  abstract public void m3();          //method declaration
		
	
	
}
