package Abstract_Class;

public class Concrete_Class extends Incompleteclassor_or_Abstractclass
{

      //Completed Method
	   public void m2()          //method declaration
	   {
		  System.out.println("Method m2 is completed in concrete class"); // Method defination
	   }
	   
	   
	
	   //Completed Method
	  public void m3()          //method declaration
	  {
		  System.out.println("Method m3 is completed in concrete class"); // Method defination
	  }
		
		
		

	
}
