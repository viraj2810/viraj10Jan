package Abstract_Class;

public class Complete_class 
{
	// Complete Method
	public void m1()       //method declaration
	{
		System.out.println("Hi"); // Method defination
	}
	
	// Complete Method
	public void m2()       //method declaration
	{
		System.out.println("Hello"); // Method defination
	}
	
	
	

}
