package datatypes;

public class datatype1 
{

	public static void main(String[] args) 
	{
		// main method body
		
		// Variable declaration
		 
		String X;           //datatype variablename
		 
		
		//Variable initialzation
		 
		X="Google LLC is an American multinational technology company that specializes in Internet-related services and products, which include a search engine, online advertising technologies, cloud computing, software, and hardware.";        //variablename=variableinformation/data;
		
		
		
		//usage
		 
		  System.out.println(X);
		
		  
		  
		  
		  
		
		 
		  
	}
	
	
	
	
	
	
	
	
}
