package Basic;

public class Sample3 
{

	// Class body
	
	public static void main(String[] args) 
	{
		  // main method body
		
		System.out.println("Hi");      // printing statement
		
		System.out.println("Hello");   // printing statement
	}
	
	
	
}
