package Basic;

public class Sample4 
{
	// Class body
	
	public static void main(String[] args) 
	{
		// Main method body
		
		System.out.println("Rohit");     // Printing statement
		System.out.println("Hi");     // Printing statement
		System.out.println("Hi");     // Printing statement
		System.out.println("Hi");     // Printing statement
		System.out.println("Hi");     // Printing statement
	}
	
	

}
