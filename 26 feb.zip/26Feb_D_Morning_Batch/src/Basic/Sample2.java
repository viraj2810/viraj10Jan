package Basic;

public class Sample2
{
	// Class body
	
	public static void main(String[] args) // main method 
	{   // main method body
		
		System.out.println("Good Evening");   //printing statement
		
		
	}
	
	
	
	
	
	
}
