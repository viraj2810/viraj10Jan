package Basic;

public class Sample1
{

	// Class Body
	
	public static void main(String[] args)  // Main method
	{
		// Main method Body
		
		System.out.println("Good Morning");  // Printing statement
		
		
		
		
	}
	
	

}
