package variables;

public class variable3
{

	public static void main(String[] args) 
	{
		// main method body
		
		// Variable declaration
		  String Studentname;           //datatype variablename  
		  int Studentrollno;           //datatype variablename
		  char Studentgrade;          //datatype variablename
		  float Studentpercentage;   //datatype variablename
		
		//Variable initialzation
		  Studentname="Rohit";      //variablename="Variable information/data";
		  Studentrollno=10;       //variablename=variableinformation/data;
		  Studentgrade='A';         //variablename='variableinformation/data'; 
		  Studentpercentage=75.25f;  //variablename=variableinformation/data f;
		
		//usage
		  System.out.println("Student Name: "+Studentname);
		  System.out.println("Student roll no: "+Studentrollno);
		  System.out.println("Student grade:"+Studentgrade);
		  System.out.println("Student Percentage :"+Studentpercentage+"%");
		  
		  
		  
		  
		
		 
		  
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
