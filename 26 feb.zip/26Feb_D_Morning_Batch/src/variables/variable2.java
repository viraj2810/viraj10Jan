package variables;

public class variable2 
{
	
	public static void main(String[] args) 
	{
		// Variable declaration
		
		 String Sgrade;
		
		
		//Variable initialzation
		 Sgrade="A+";
		
		
		//usage
		System.out.println(Sgrade);
		
		
	}
	
	
	
	
	
	
	
	

}
