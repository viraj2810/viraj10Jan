package String;

public class sample4 
{
	public static void main(String[] args) 
	{
		
		   sample3.m1();
		
		sample3 s3=new sample3();
		
	}
	
	
	
	
	
	
	

}
