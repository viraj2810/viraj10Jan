package String;

public class String_Methods 
{

	public static void main(String[] args) 
	{
		String S1="velocity";
		String S2="";
		String S3="ABCD";
		String S4="VELOCITY";
		String S5="city";
		String S6="abcabab";
		String S7="classes";
		String S8="Manual Classes";
			
		System.out.println(S1.length()); //8         //To find length/size of String
		System.out.println(S1.isEmpty());//false    //to verify whether string is empty or not
		System.out.println(S2.isEmpty());//true
		System.out.println(S1.toUpperCase());//VELOCITY  //To print string in lower case	
		System.out.println(S3.toLowerCase());//abcd   //To print string in lower case	
		
		//Compare 2 strings
		System.out.println(S1.equals(S4));//false    // To compare two Strings(String S1 & String S4) with case sensitive
		System.out.println(S1.equalsIgnoreCase(S4));//true  // To compare two Strings(String S1 & String S4) without case sensitive 
		System.out.println(S1.contains(S5));//true  // To compare two Strings(String S1 & String S5)
		System.out.println(S4.contains(S5));//false   // To compare two Strings(String S4 & String S5)
			
		System.out.println(S1.charAt(4));//c                //To get single character
		System.out.println(S1.startsWith("vel"));//true       // to verify String S1 starts with 'vel'  with case sensitive
		System.out.println(S1.endsWith("ty"));//true	   // to verify String s1 ends with 'ty' with case sensitive	
		System.out.println(S1.indexOf('i'));//5
		
		System.out.println(S6.indexOf('b'));//1
		System.out.println(S6.indexOf('a'));//0
		System.out.println(S6.lastIndexOf('a'));//5
		
		System.out.println(S1.substring(4));//city
		System.out.println(S1.substring(2,6));//loci
		
		System.out.println(S1+S7);//velocityclasses
		System.out.println(S1.concat(S7)); //velocityclasses
		
		System.out.println(S8.replace("Manual", "Automation"));//Automation classes
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
