package String;

public class Sample2 
{

	public static void main(String[] args) 
	{
		
		 String S1="abc";
		
		      S1=S1+"de"; //abcde
		
		System.out.println(S1);
		
		
		
	}
	
	
	
	
}
