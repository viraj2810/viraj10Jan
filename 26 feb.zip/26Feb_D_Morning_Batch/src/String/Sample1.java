package String;

public class Sample1 
{
	
	public static void main(String[] args) 
	{
		//with using new keyword
		String S1=new String("abc");                   //classname Objectname=new Classname();
		
		       //OR
		//Without using new keyword
		//String declartion and initialisation
		    String S2="abc";
		
		
	}
	


}
