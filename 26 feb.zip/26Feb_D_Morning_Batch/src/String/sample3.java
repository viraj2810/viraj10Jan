package String;

public class sample3 
{
	
	public static void main(String[] args)
	{
		final int a=10;            //initilisation
		System.out.println(a);//10
		
	
		
	}
	
  
	
	
	final public static void m1()
	{
		System.out.println("Hi");
	}
	
	final public static void m1(String s1)
	{
		System.out.println("Hi");
	}
	
	

}
