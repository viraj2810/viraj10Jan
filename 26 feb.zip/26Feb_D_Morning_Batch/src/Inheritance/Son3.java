package Inheritance;

public class Son3 extends Father1
{  // sub class
	
	public void Laptop() 
	{
		System.out.println("Dell");
	}
	
	
	
	
}
