package Inheritance;

public class Son1 extends Father1
{
	// Sub class
	public void Mobile() 
	{
		System.out.println("Samung A50");
	}
	
	
	

}
