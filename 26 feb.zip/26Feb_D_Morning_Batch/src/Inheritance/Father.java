package Inheritance;

   //Single level Inheritance
public class Father
{    //super class

	public void Car() 
	{
		System.out.println("Car:Honda City");
	}
	
	public void Money() 
	{
		System.out.println("Money: 1 Lakh");
	}
	
	public void Home() 
	{
		System.out.println("Home:2 BHK");
	}
	
	
	
	
	
}
