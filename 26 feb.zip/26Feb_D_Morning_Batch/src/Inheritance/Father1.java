package Inheritance;

public class Father1 
{
    //Super class
	public void Property() 
	{
		System.out.println("Home, Car, Money, Diamonds");
	}
	
	
}
