package Inheritance;

public class WhatsappV2 extends WhatsappV1
{

	public void AudioCalling() 
	{
		System.out.println("Audio Calling");
	} 
	
	
}
