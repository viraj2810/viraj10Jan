package Inheritance;

public class Multilevel_Inheritance 
{

	public static void main(String[] args) 
	{
		
		WhatsappV3 V3=new WhatsappV3();
		
		V3.VideoCalling();
		V3.AudioCalling();
		V3.Textmsg();
		
	
	}
	
	
	
}
