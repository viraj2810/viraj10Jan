package Inheritance;

public class WhatsappV1 
{

	public void Textmsg() 
	{
		System.out.println("Text Message");
	} 
	
	
	
}
