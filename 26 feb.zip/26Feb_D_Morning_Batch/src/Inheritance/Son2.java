package Inheritance;

public class Son2 extends Father1
{  // sub Class
	public void Bike() 
	{
		System.out.println("Unicorn");
	}
	
	

}
