package Inheritance;

public class Son extends Father
{
	//sub class
	public void Mobile() 
	{
		System.out.println("Mobile:Samsung A50");
	}
	
	
	
	
	

}
