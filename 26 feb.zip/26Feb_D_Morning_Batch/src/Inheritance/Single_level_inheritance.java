package Inheritance;

public class Single_level_inheritance 
{
	
	public static void main(String[] args) 
	{
		//create object of son class
	     	Son S1=new Son();
		     S1.Mobile();
		     S1.Car();
		     S1.Money();
		     S1.Home();
		
		
	}
	
	
	
	
	
	
	
	
}
