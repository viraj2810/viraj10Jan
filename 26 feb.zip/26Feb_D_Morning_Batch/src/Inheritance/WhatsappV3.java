package Inheritance;

public class WhatsappV3 extends WhatsappV2
{
	
	public void VideoCalling() 
	{
		System.out.println("Video Calling");
	} 
	
	
}
